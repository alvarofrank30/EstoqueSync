# EXPLAIN ANALYZE dos índices (item 11 do dossiê)

**Como foi medido.** Com o seed (100 pedidos) o PostgreSQL ignora índices, porque varrer 100 linhas é mais barato.
Por isso foi criado um banco de teste separado (`estoque_perf`) com os scripts 01 a 04 e uma carga em massa:
**200.100 pedidos, 600.300 itens e 600.375 movimentações** (carga feita com `SET session_replication_role = replica`,
só neste teste, para não disparar os gatilhos). Cada consulta rodou antes e depois de `05_indices.sql`.
Para reproduzir, use os comandos `EXPLAIN (ANALYZE, COSTS OFF, TIMING OFF, SUMMARY ON)` abaixo.

| # | Consulta | Índice criado | Plano antes | Plano depois | Antes | Depois | Ganho |
|---|---|---|---|---|---|---|---|
| 1 | `SELECT SUM(quantidade) FROM item_pedido WHERE id_produto = 6` | `idx_item_pedido_id_produto` | Parallel Seq Scan | Bitmap Index Scan | 23,5 ms | 9,4 ms | 2,5x |
| 2 | `SELECT * FROM pedido WHERE data_pedido >= now() - interval '7 days'` | `idx_pedido_data_pedido` | Parallel Seq Scan | Bitmap Index Scan | 21,3 ms | 1,1 ms | 20x |
| 3 | `SELECT * FROM pedido WHERE id_cliente = 12` | `idx_pedido_id_cliente` | Seq Scan | Bitmap Index Scan | 11,6 ms | 2,3 ms | 5x |
| 4 | `SELECT * FROM movimentacao_estoque WHERE id_produto = 6 ORDER BY data_movimento` | `idx_movimentacao_estoque_id_produto` | Parallel Seq Scan + Sort | Bitmap Index Scan + Sort | 32,3 ms | 14,5 ms | 2,2x |

**Leitura dos resultados**

- Quanto mais seletiva a consulta (poucas linhas entre muitas), maior o ganho: a consulta 2 devolve 1% da tabela e ficou 20x mais rápida.
- Na consulta 4 o índice acelerou a busca por produto, mas o `Sort` continuou, porque o produto 6 representa ~3% da tabela e o
  planejador preferiu um Bitmap Scan (que não devolve ordenado) a um Index Scan ordenado. Em tabelas maiores ou
  com `LIMIT`, o índice composto `(id_produto, data_movimento)` passa a entregar a ordem sem ordenar.
- O PostgreSQL não cria índice automático em colunas de chave estrangeira; por isso `id_produto` e `id_cliente` precisam de índice manual.

## Saídas completas (antes)

```
== Q1  SELECT SUM(quantidade) FROM item_pedido WHERE id_produto = 6
                                  QUERY PLAN                                   
-------------------------------------------------------------------------------
 Finalize Aggregate (actual rows=1 loops=1)
   ->  Gather (actual rows=3 loops=1)
         Workers Planned: 2
         Workers Launched: 2
         ->  Partial Aggregate (actual rows=1 loops=3)
               ->  Parallel Seq Scan on item_pedido (actual rows=6671 loops=3)
                     Filter: (id_produto = 6)
                     Rows Removed by Filter: 193429
 Planning Time: 0.277 ms
 Execution Time: 23.459 ms
(10 rows)

== Q2  SELECT * FROM pedido WHERE data_pedido >= now() - interval '7 days'
                          QUERY PLAN                           
---------------------------------------------------------------
 Gather (actual rows=1924 loops=1)
   Workers Planned: 1
   Workers Launched: 1
   ->  Parallel Seq Scan on pedido (actual rows=962 loops=2)
         Filter: (data_pedido >= (now() - '7 days'::interval))
         Rows Removed by Filter: 99088
 Planning Time: 0.182 ms
 Execution Time: 21.309 ms
(8 rows)

== Q3  SELECT * FROM pedido WHERE id_cliente = 12
                  QUERY PLAN                   
-----------------------------------------------
 Seq Scan on pedido (actual rows=6901 loops=1)
   Filter: (id_cliente = 12)
   Rows Removed by Filter: 193199
 Planning Time: 0.049 ms
 Execution Time: 11.617 ms
(5 rows)

== Q4  SELECT * FROM movimentacao_estoque WHERE id_produto = 6 ORDER BY data_movimento
                                    QUERY PLAN                                    
----------------------------------------------------------------------------------
 Gather Merge (actual rows=20015 loops=1)
   Workers Planned: 2
   Workers Launched: 2
   ->  Sort (actual rows=6672 loops=3)
         Sort Key: data_movimento
         Sort Method: quicksort  Memory: 1066kB
         Worker 0:  Sort Method: quicksort  Memory: 482kB
         Worker 1:  Sort Method: quicksort  Memory: 474kB
         ->  Parallel Seq Scan on movimentacao_estoque (actual rows=6672 loops=3)
               Filter: (id_produto = 6)
               Rows Removed by Filter: 193453
 Planning Time: 0.170 ms
 Execution Time: 32.298 ms
(13 rows)

```

## Saídas completas (depois)

```
== Q1  SELECT SUM(quantidade) FROM item_pedido WHERE id_produto = 6
                                       QUERY PLAN                                        
-----------------------------------------------------------------------------------------
 Aggregate (actual rows=1 loops=1)
   ->  Bitmap Heap Scan on item_pedido (actual rows=20013 loops=1)
         Recheck Cond: (id_produto = 6)
         Heap Blocks: exact=3824
         ->  Bitmap Index Scan on idx_item_pedido_id_produto (actual rows=20013 loops=1)
               Index Cond: (id_produto = 6)
 Planning Time: 0.319 ms
 Execution Time: 9.431 ms
(8 rows)

== Q2  SELECT * FROM pedido WHERE data_pedido >= now() - interval '7 days'
                                  QUERY PLAN                                  
------------------------------------------------------------------------------
 Bitmap Heap Scan on pedido (actual rows=1924 loops=1)
   Recheck Cond: (data_pedido >= (now() - '7 days'::interval))
   Heap Blocks: exact=298
   ->  Bitmap Index Scan on idx_pedido_data_pedido (actual rows=1924 loops=1)
         Index Cond: (data_pedido >= (now() - '7 days'::interval))
 Planning Time: 0.224 ms
 Execution Time: 1.086 ms
(7 rows)

== Q3  SELECT * FROM pedido WHERE id_cliente = 12
                                 QUERY PLAN                                  
-----------------------------------------------------------------------------
 Bitmap Heap Scan on pedido (actual rows=6901 loops=1)
   Recheck Cond: (id_cliente = 12)
   Heap Blocks: exact=1669
   ->  Bitmap Index Scan on idx_pedido_id_cliente (actual rows=6901 loops=1)
         Index Cond: (id_cliente = 12)
 Planning Time: 0.039 ms
 Execution Time: 2.325 ms
(7 rows)

== Q4  SELECT * FROM movimentacao_estoque WHERE id_produto = 6 ORDER BY data_movimento
                                            QUERY PLAN                                            
--------------------------------------------------------------------------------------------------
 Sort (actual rows=20015 loops=1)
   Sort Key: data_movimento
   Sort Method: quicksort  Memory: 2020kB
   ->  Bitmap Heap Scan on movimentacao_estoque (actual rows=20015 loops=1)
         Recheck Cond: (id_produto = 6)
         Heap Blocks: exact=4989
         ->  Bitmap Index Scan on idx_movimentacao_estoque_id_produto (actual rows=20015 loops=1)
               Index Cond: (id_produto = 6)
 Planning Time: 0.184 ms
 Execution Time: 14.456 ms
(10 rows)

```
