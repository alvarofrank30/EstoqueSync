<?php
// Cadastro de clientes (bares, mercados, restaurantes): incluir, listar, editar e desativar.
require __DIR__ . '/conexao.php';
require __DIR__ . '/layout.php';

$pdo      = conectar();
$mensagem = '';
$erro     = '';

// ---------- 1. Ações enviadas pelo formulário (POST) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $acao = $_POST['acao'] ?? '';
    try {
        if ($acao === 'salvar') {
            $id       = (int) ($_POST['id_cliente'] ?? 0);
            $nome     = trim($_POST['nome'] ?? '');
            $email    = trim($_POST['email'] ?? '');
            $telefone = trim($_POST['telefone'] ?? '') ?: null;   // vazio vira NULL de verdade
            $cidade   = trim($_POST['cidade'] ?? '');

            if ($nome === '' || $email === '' || $cidade === '') {
                $erro = 'Preencha nome, e-mail e cidade.';
            } elseif ($id > 0) {
                // Consulta parametrizada: os valores nunca são colados no SQL
                transacao($pdo, fn(PDO $pdo) => $pdo->prepare(
                    'UPDATE cliente SET nome = ?, email = ?, telefone = ?, cidade = ? WHERE id_cliente = ?'
                )->execute([$nome, $email, $telefone, $cidade, $id]));
                $mensagem = 'Cliente atualizado com sucesso.';
            } else {
                transacao($pdo, fn(PDO $pdo) => $pdo->prepare(
                    'INSERT INTO cliente (nome, email, telefone, cidade) VALUES (?, ?, ?, ?)'
                )->execute([$nome, $email, $telefone, $cidade]));
                $mensagem = 'Cliente cadastrado com sucesso.';
            }
        } elseif ($acao === 'desativar' || $acao === 'reativar') {
            transacao($pdo, function (PDO $pdo) use ($acao) {
                $st = $pdo->prepare('UPDATE cliente SET ativo = ? WHERE id_cliente = ?');
                $st->bindValue(1, $acao === 'reativar', PDO::PARAM_BOOL);
                $st->bindValue(2, (int) ($_POST['id_cliente'] ?? 0), PDO::PARAM_INT);
                $st->execute();
            });
            $mensagem = $acao === 'reativar' ? 'Cliente reativado.' : 'Cliente desativado.';
        }
    } catch (PDOException $e) {
        $erro = mensagem_erro($e);
    }
}

// ---------- 2. Cliente em edição (?editar=ID) ----------
$cliente = ['id_cliente' => '', 'nome' => '', 'email' => '', 'telefone' => '', 'cidade' => ''];
if (isset($_GET['editar'])) {
    $st = $pdo->prepare('SELECT * FROM cliente WHERE id_cliente = ?');
    $st->execute([(int) $_GET['editar']]);
    $cliente = $st->fetch() ?: $cliente;
}
if ($erro !== '' && ($_POST['acao'] ?? '') === 'salvar') {
    $cliente = array_merge($cliente, array_intersect_key($_POST, $cliente));
}

// ---------- 3. Listagem com busca e filtro ----------
$busca  = trim($_GET['busca'] ?? '');
$filtro = $_GET['filtro'] ?? 'ativos';

$sql = 'SELECT id_cliente, nome, email, telefone, cidade, ativo
        FROM cliente
        WHERE (nome ILIKE ? OR email ILIKE ? OR cidade ILIKE ?)';
if ($filtro === 'ativos')   $sql .= ' AND ativo';
if ($filtro === 'inativos') $sql .= ' AND NOT ativo';
$sql .= ' ORDER BY nome';

$st = $pdo->prepare($sql);
$st->execute(["%$busca%", "%$busca%", "%$busca%"]);
$clientes = $st->fetchAll();

cabecalho('Cadastro de Clientes', 'clientes');
avisos($mensagem, $erro);
?>
    <section class="cartao">
        <h2><?= $cliente['id_cliente'] ? 'Editar cliente' : 'Novo cliente' ?></h2>
        <form method="post" action="clientes.php">
            <?= csrf_campo() ?>
            <input type="hidden" name="acao" value="salvar">
            <input type="hidden" name="id_cliente" value="<?= h($cliente['id_cliente']) ?>">

            <div class="grade">
                <label>Nome *
                    <input type="text" name="nome" maxlength="120" required value="<?= h($cliente['nome']) ?>">
                </label>
                <label>E-mail *
                    <input type="email" name="email" maxlength="150" required value="<?= h($cliente['email']) ?>">
                </label>
                <label>Telefone
                    <input type="text" name="telefone" maxlength="15" placeholder="(91) 90000-0000" value="<?= h($cliente['telefone']) ?>">
                </label>
                <label>Cidade *
                    <input type="text" name="cidade" maxlength="60" required value="<?= h($cliente['cidade']) ?>">
                </label>
            </div>
            <p class="pequeno">Use apenas dados fictícios (LGPD).</p>

            <div class="botoes">
                <button type="submit">Salvar</button>
                <?php if ($cliente['id_cliente']): ?><a href="clientes.php">Cancelar</a><?php endif; ?>
            </div>
        </form>
    </section>

    <section class="cartao">
        <h2>Clientes</h2>
        <form method="get" class="busca">
            <input type="text" name="busca" placeholder="Buscar por nome, e-mail ou cidade" value="<?= h($busca) ?>">
            <select name="filtro">
                <option value="ativos"   <?= $filtro === 'ativos' ? 'selected' : '' ?>>Ativos</option>
                <option value="inativos" <?= $filtro === 'inativos' ? 'selected' : '' ?>>Inativos</option>
                <option value="todos"    <?= $filtro === 'todos' ? 'selected' : '' ?>>Todos</option>
            </select>
            <button type="submit">Filtrar</button>
        </form>

        <table>
            <thead>
                <tr><th>Nome</th><th>E-mail</th><th>Telefone</th><th>Cidade</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($clientes as $c): ?>
                <tr class="<?= $c['ativo'] ? '' : 'inativo' ?>">
                    <td><?= h($c['nome']) ?></td>
                    <td><?= h($c['email']) ?></td>
                    <td><?= h($c['telefone']) ?></td>
                    <td><?= h($c['cidade']) ?></td>
                    <td class="acoes">
                        <a href="?editar=<?= $c['id_cliente'] ?>">Editar</a>
                        <form method="post">
                            <?= csrf_campo() ?>
                            <input type="hidden" name="id_cliente" value="<?= $c['id_cliente'] ?>">
                            <?php if ($c['ativo']): ?>
                                <button name="acao" value="desativar" class="link"
                                        onclick="return confirm('Desativar este cliente?')">Desativar</button>
                            <?php else: ?>
                                <button name="acao" value="reativar" class="link verde">Reativar</button>
                            <?php endif; ?>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$clientes): ?>
                <tr><td colspan="5" class="vazio">Nenhum cliente encontrado.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </section>
<?php rodape();
