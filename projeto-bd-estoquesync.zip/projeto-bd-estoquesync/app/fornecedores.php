<?php
// Cadastro de fornecedores (quem abastece o estoque): incluir, listar, editar e desativar.
require __DIR__ . '/conexao.php';
require __DIR__ . '/layout.php';

$pdo      = conectar();
$mensagem = '';
$erro     = '';

// ---------- 1. Ações enviadas pelo formulário (POST) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $acao = $_POST['acao'] ?? '';
    try {
        if ($acao === 'salvar') {
            $id       = (int) ($_POST['id_fornecedor'] ?? 0);
            $razao    = trim($_POST['razao_social'] ?? '');
            $email    = trim($_POST['email'] ?? '');
            $telefone = trim($_POST['telefone'] ?? '') ?: null;   // vazio vira NULL de verdade
            $cidade   = trim($_POST['cidade'] ?? '');

            if ($razao === '' || $email === '' || $cidade === '') {
                $erro = 'Preencha razão social, e-mail e cidade.';
            } elseif ($id > 0) {
                // Consulta parametrizada: os valores nunca são colados no SQL
                transacao($pdo, fn(PDO $pdo) => $pdo->prepare(
                    'UPDATE fornecedor SET razao_social = ?, email = ?, telefone = ?, cidade = ? WHERE id_fornecedor = ?'
                )->execute([$razao, $email, $telefone, $cidade, $id]));
                $mensagem = 'Fornecedor atualizado com sucesso.';
            } else {
                transacao($pdo, fn(PDO $pdo) => $pdo->prepare(
                    'INSERT INTO fornecedor (razao_social, email, telefone, cidade) VALUES (?, ?, ?, ?)'
                )->execute([$razao, $email, $telefone, $cidade]));
                $mensagem = 'Fornecedor cadastrado com sucesso.';
            }
        } elseif ($acao === 'desativar' || $acao === 'reativar') {
            transacao($pdo, function (PDO $pdo) use ($acao) {
                $st = $pdo->prepare('UPDATE fornecedor SET ativo = ? WHERE id_fornecedor = ?');
                $st->bindValue(1, $acao === 'reativar', PDO::PARAM_BOOL);
                $st->bindValue(2, (int) ($_POST['id_fornecedor'] ?? 0), PDO::PARAM_INT);
                $st->execute();
            });
            $mensagem = $acao === 'reativar' ? 'Fornecedor reativado.' : 'Fornecedor desativado.';
        }
    } catch (PDOException $e) {
        $erro = mensagem_erro($e);
    }
}

// ---------- 2. Fornecedor em edição (?editar=ID) ----------
$fornecedor = ['id_fornecedor' => '', 'razao_social' => '', 'email' => '', 'telefone' => '', 'cidade' => ''];
if (isset($_GET['editar'])) {
    $st = $pdo->prepare('SELECT * FROM fornecedor WHERE id_fornecedor = ?');
    $st->execute([(int) $_GET['editar']]);
    $fornecedor = $st->fetch() ?: $fornecedor;
}
if ($erro !== '' && ($_POST['acao'] ?? '') === 'salvar') {
    $fornecedor = array_merge($fornecedor, array_intersect_key($_POST, $fornecedor));
}

// ---------- 3. Listagem com busca e filtro ----------
$busca  = trim($_GET['busca'] ?? '');
$filtro = $_GET['filtro'] ?? 'ativos';

$sql = 'SELECT id_fornecedor, razao_social, email, telefone, cidade, ativo
        FROM fornecedor
        WHERE (razao_social ILIKE ? OR email ILIKE ? OR cidade ILIKE ?)';
if ($filtro === 'ativos')   $sql .= ' AND ativo';
if ($filtro === 'inativos') $sql .= ' AND NOT ativo';
$sql .= ' ORDER BY razao_social';

$st = $pdo->prepare($sql);
$st->execute(["%$busca%", "%$busca%", "%$busca%"]);
$fornecedors = $st->fetchAll();

cabecalho('Cadastro de Fornecedores', 'fornecedores');
avisos($mensagem, $erro);
?>
    <section class="cartao">
        <h2><?= $fornecedor['id_fornecedor'] ? 'Editar fornecedor' : 'Novo fornecedor' ?></h2>
        <form method="post" action="fornecedores.php">
            <?= csrf_campo() ?>
            <input type="hidden" name="acao" value="salvar">
            <input type="hidden" name="id_fornecedor" value="<?= h($fornecedor['id_fornecedor']) ?>">

            <div class="grade">
                <label>Razão social *
                    <input type="text" name="razao_social" maxlength="120" required value="<?= h($fornecedor['razao_social']) ?>">
                </label>
                <label>E-mail *
                    <input type="email" name="email" maxlength="150" required value="<?= h($fornecedor['email']) ?>">
                </label>
                <label>Telefone
                    <input type="text" name="telefone" maxlength="15" placeholder="(91) 90000-0000" value="<?= h($fornecedor['telefone']) ?>">
                </label>
                <label>Cidade *
                    <input type="text" name="cidade" maxlength="60" required value="<?= h($fornecedor['cidade']) ?>">
                </label>
            </div>
            <p class="pequeno">Use apenas empresas fictícias.</p>

            <div class="botoes">
                <button type="submit">Salvar</button>
                <?php if ($fornecedor['id_fornecedor']): ?><a href="fornecedores.php">Cancelar</a><?php endif; ?>
            </div>
        </form>
    </section>

    <section class="cartao">
        <h2>Fornecedores</h2>
        <form method="get" class="busca">
            <input type="text" name="busca" placeholder="Buscar por razão social, e-mail ou cidade" value="<?= h($busca) ?>">
            <select name="filtro">
                <option value="ativos"   <?= $filtro === 'ativos' ? 'selected' : '' ?>>Ativos</option>
                <option value="inativos" <?= $filtro === 'inativos' ? 'selected' : '' ?>>Inativos</option>
                <option value="todos"    <?= $filtro === 'todos' ? 'selected' : '' ?>>Todos</option>
            </select>
            <button type="submit">Filtrar</button>
        </form>

        <table>
            <thead>
                <tr><th>Razão social</th><th>E-mail</th><th>Telefone</th><th>Cidade</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($fornecedors as $c): ?>
                <tr class="<?= $c['ativo'] ? '' : 'inativo' ?>">
                    <td><?= h($c['razao_social']) ?></td>
                    <td><?= h($c['email']) ?></td>
                    <td><?= h($c['telefone']) ?></td>
                    <td><?= h($c['cidade']) ?></td>
                    <td class="acoes">
                        <a href="?editar=<?= $c['id_fornecedor'] ?>">Editar</a>
                        <form method="post">
                            <?= csrf_campo() ?>
                            <input type="hidden" name="id_fornecedor" value="<?= $c['id_fornecedor'] ?>">
                            <?php if ($c['ativo']): ?>
                                <button name="acao" value="desativar" class="link"
                                        onclick="return confirm('Desativar este fornecedor?')">Desativar</button>
                            <?php else: ?>
                                <button name="acao" value="reativar" class="link verde">Reativar</button>
                            <?php endif; ?>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$fornecedors): ?>
                <tr><td colspan="5" class="vazio">Nenhum fornecedor encontrado.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </section>
<?php rodape();
