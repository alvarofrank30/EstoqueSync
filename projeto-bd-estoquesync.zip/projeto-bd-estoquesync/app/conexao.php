<?php
// Base comum a todas as telas:
//  - conexão PDO com o PostgreSQL (credenciais vindas do .env)
//  - transação (BEGIN / COMMIT / ROLLBACK) com o usuário da tela para a auditoria
//  - tradução de erros do banco para mensagens que o usuário entende
//  - proteção CSRF e funções de formatação

// Cookie de sessão não acessível por JavaScript e não enviado entre sites
session_set_cookie_params(['httponly' => true, 'samesite' => 'Strict']);
session_start();

function conectar(): PDO
{
    $env = parse_ini_file(__DIR__ . '/.env');
    if ($env === false) {
        die('Arquivo .env não encontrado. Copie .env.example para .env e ajuste.');
    }

    $dsn = "pgsql:host={$env['DB_HOST']};port={$env['DB_PORT']};dbname={$env['DB_NAME']}";

    return new PDO($dsn, $env['DB_USER'], $env['DB_PASS'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // erro vira exceção
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}

// Executa $fn dentro de uma transação. Se qualquer comando falhar, tudo é
// desfeito (ROLLBACK). O nome do operador vai para o banco com set_config
// (is_local = true: vale só até o fim da transação) e o gatilho de auditoria
// o grava em auditoria.usuario_app.
function transacao(PDO $pdo, callable $fn, string $usuario = 'operador_web')
{
    $pdo->beginTransaction();                                            // BEGIN
    try {
        $pdo->prepare("SELECT set_config('app.usuario', ?, true)")->execute([$usuario]);
        $resultado = $fn($pdo);
        $pdo->commit();                                                  // COMMIT
        return $resultado;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();                                            // ROLLBACK
        }
        throw $e;
    }
}

// Traduz erros do PostgreSQL para mensagens que o usuário entende.
function mensagem_erro(PDOException $e): string
{
    $codigo = (string) $e->getCode();
    $texto  = $e->errorInfo[2] ?? $e->getMessage();

    // Regras de negócio criadas nos gatilhos (SQLSTATE próprio EST01..EST07):
    // a mensagem do RAISE EXCEPTION já foi escrita para o usuário.
    if (str_starts_with($codigo, 'EST')) {
        $texto = preg_replace('/^ERROR:\s+/', '', $texto);
        return trim(preg_split('/\R/', $texto)[0]);
    }

    // Restrições nomeadas no DDL (o nome aparece na mensagem do PostgreSQL)
    $restricoes = [
        'uq_produto_sku'          => 'Já existe um produto com este SKU.',
        'uq_cliente_email'        => 'Este e-mail já está cadastrado para outro cliente.',
        'uq_fornecedor_email'     => 'Este e-mail já está cadastrado para outro fornecedor.',
        'pk_item_pedido'          => 'O mesmo produto aparece mais de uma vez no pedido.',
        'ck_produto_preco'        => 'O preço deve ser maior que zero.',
        'ck_produto_volume'       => 'O volume deve ser maior que zero.',
        'ck_estoque_minimo'       => 'O estoque mínimo não pode ser negativo.',
        'ck_cliente_email'        => 'Informe um e-mail válido.',
        'ck_fornecedor_email'     => 'Informe um e-mail válido.',
        'ck_item_pedido_quantidade' => 'A quantidade deve ser maior que zero.',
        'ck_movimentacao_estoque_quantidade' => 'A quantidade deve ser maior que zero.',
        'fk_produto_categoria'    => 'Escolha uma categoria válida.',
        'fk_produto_fornecedor'   => 'Escolha um fornecedor válido.',
        'fk_pedido_cliente'       => 'Escolha um cliente válido.',
        'fk_pedido_vendedor'      => 'Escolha um vendedor válido.',
    ];
    foreach ($restricoes as $nome => $mensagem) {
        if (str_contains($texto, $nome)) {
            return $mensagem;
        }
    }

    // Códigos gerais do SQL padrão, quando a restrição não está na lista
    return match ($codigo) {
        '23502' => 'Preencha todos os campos obrigatórios.',
        '23505' => 'Já existe um registro com estes dados.',
        '23503' => 'Valor inválido: o registro relacionado não existe.',
        '23514' => 'Algum valor informado não é permitido.',
        '42501' => 'Esta operação não é permitida para o usuário da aplicação.',
        default => 'Não foi possível concluir a operação. Tente novamente.',
    };
}

// ---------- CSRF: impede que outro site envie formulários em nome do usuário ----------
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_campo(): string
{
    return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">';
}

function csrf_validar(): void
{
    $esperado = $_SESSION['csrf'] ?? '';
    $recebido = $_POST['csrf'] ?? '';
    // O token esperado não pode ser vazio: '' == '' passaria sem proteção nenhuma
    if ($esperado === '' || !is_string($recebido) || !hash_equals($esperado, $recebido)) {
        http_response_code(403);
        die('Requisição inválida (token de segurança ausente ou expirado). Volte e tente de novo.');
    }
}

// ---------- formatação ----------

// Escapa texto para o HTML (evita que dados quebrem a página: XSS)
function h($v): string
{
    return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
}

function moeda($v): string
{
    return 'R$ ' . number_format((float) $v, 2, ',', '.');
}

// "1.234,50" ou "12,5" ou "12.5" -> "1234.50" / "12.5"; texto inválido -> null
function decimal_br(string $v): ?string
{
    $v = trim($v);
    if (str_contains($v, ',')) {
        $v = str_replace(',', '.', str_replace('.', '', $v));
    }
    return is_numeric($v) ? $v : null;
}
