<?php
// Cadastro de produtos: incluir, listar (busca e filtro), editar e desativar.
// Tem DUAS chaves estrangeiras em listas suspensas: categoria e fornecedor.
require __DIR__ . '/conexao.php';
require __DIR__ . '/layout.php';

$pdo      = conectar();
$mensagem = '';
$erro     = '';

// ---------- 1. Ações enviadas pelo formulário (POST) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $acao = $_POST['acao'] ?? '';
    try {
        if ($acao === 'salvar') {
            $id         = (int) ($_POST['id_produto'] ?? 0);
            $sku        = strtoupper(trim($_POST['sku'] ?? ''));
            $nome       = trim($_POST['nome'] ?? '');
            $volume     = (int) ($_POST['volume_ml'] ?? 0);
            $preco      = decimal_br($_POST['preco_venda'] ?? '');
            $categoria  = (int) ($_POST['id_categoria'] ?? 0);
            $fornecedor = (int) ($_POST['id_fornecedor'] ?? 0);
            $minimo     = (int) ($_POST['estoque_minimo'] ?? 0);

            if ($sku === '' || $nome === '' || $volume <= 0 || $preco === null || !$categoria || !$fornecedor) {
                $erro = 'Preencha SKU, nome, volume, preço, categoria e fornecedor.';
            } else {
                // Dois comandos (produto + estoque mínimo): ou gravam os dois, ou nenhum
                transacao($pdo, function (PDO $pdo) use (&$id, $sku, $nome, $volume, $preco, $categoria, $fornecedor, $minimo) {
                    if ($id > 0) {
                        $pdo->prepare('UPDATE produto SET sku = ?, nome = ?, volume_ml = ?, preco_venda = ?,
                                              id_categoria = ?, id_fornecedor = ? WHERE id_produto = ?')
                            ->execute([$sku, $nome, $volume, $preco, $categoria, $fornecedor, $id]);
                    } else {
                        // O gatilho trg_criar_estoque cria a linha de estoque (saldo 0)
                        $st = $pdo->prepare('INSERT INTO produto (sku, nome, volume_ml, preco_venda, id_categoria, id_fornecedor)
                                             VALUES (?, ?, ?, ?, ?, ?) RETURNING id_produto');
                        $st->execute([$sku, $nome, $volume, $preco, $categoria, $fornecedor]);
                        $id = (int) $st->fetchColumn();
                    }
                    $pdo->prepare('UPDATE estoque SET estoque_minimo = ? WHERE id_produto = ?')
                        ->execute([$minimo, $id]);
                });
                $mensagem = ($_POST['id_produto'] ?? '') !== '' ? 'Produto atualizado com sucesso.' : 'Produto cadastrado com sucesso.';
            }
        } elseif ($acao === 'desativar' || $acao === 'reativar') {
            transacao($pdo, function (PDO $pdo) use ($acao) {
                $st = $pdo->prepare('UPDATE produto SET ativo = ? WHERE id_produto = ?');
                $st->bindValue(1, $acao === 'reativar', PDO::PARAM_BOOL);
                $st->bindValue(2, (int) ($_POST['id_produto'] ?? 0), PDO::PARAM_INT);
                $st->execute();
            });
            $mensagem = $acao === 'reativar' ? 'Produto reativado.' : 'Produto desativado.';
        }
    } catch (PDOException $e) {
        $erro = mensagem_erro($e);
    }
}

// ---------- 2. Produto em edição (?editar=ID) ----------
$produto = ['id_produto' => '', 'sku' => '', 'nome' => '', 'volume_ml' => '', 'preco_venda' => '',
            'id_categoria' => '', 'id_fornecedor' => '', 'estoque_minimo' => '20'];
if (isset($_GET['editar'])) {
    $st = $pdo->prepare('SELECT p.*, e.estoque_minimo FROM produto p
                         JOIN estoque e ON e.id_produto = p.id_produto WHERE p.id_produto = ?');
    $st->execute([(int) $_GET['editar']]);
    $produto = $st->fetch() ?: $produto;
    $produto['preco_venda'] = str_replace('.', ',', (string) $produto['preco_venda']);
}
// Se houve erro ao salvar, mantém o que o usuário digitou
if ($erro !== '' && ($_POST['acao'] ?? '') === 'salvar') {
    $produto = array_merge($produto, array_intersect_key($_POST, $produto));
}

// ---------- 3. Listas suspensas (chaves estrangeiras) ----------
// "OR id = atual": ao editar, mantém visível a categoria/fornecedor já gravado, mesmo que desativado
$st = $pdo->prepare('SELECT id_categoria, nome FROM categoria WHERE ativo OR id_categoria = ? ORDER BY nome');
$st->execute([(int) $produto['id_categoria']]);
$categorias = $st->fetchAll();

$st = $pdo->prepare('SELECT id_fornecedor, razao_social FROM fornecedor WHERE ativo OR id_fornecedor = ? ORDER BY razao_social');
$st->execute([(int) $produto['id_fornecedor']]);
$fornecedores = $st->fetchAll();

// ---------- 4. Listagem com busca e filtro ----------
$busca  = trim($_GET['busca'] ?? '');
$filtro = $_GET['filtro'] ?? 'ativos';

$sql = 'SELECT p.id_produto, p.sku, p.nome, p.preco_venda, p.ativo,
               c.nome AS categoria, f.razao_social AS fornecedor, e.saldo, e.estoque_minimo
        FROM produto p
        JOIN categoria  c ON c.id_categoria  = p.id_categoria
        JOIN fornecedor f ON f.id_fornecedor = p.id_fornecedor
        JOIN estoque    e ON e.id_produto    = p.id_produto
        WHERE (p.nome ILIKE ? OR p.sku ILIKE ?)';
if ($filtro === 'ativos')   $sql .= ' AND p.ativo';
if ($filtro === 'inativos') $sql .= ' AND NOT p.ativo';
$sql .= ' ORDER BY p.nome';

$st = $pdo->prepare($sql);
$st->execute(["%$busca%", "%$busca%"]);
$produtos = $st->fetchAll();

cabecalho('Cadastro de Produtos', 'produtos');
avisos($mensagem, $erro);
?>
    <section class="cartao">
        <h2><?= $produto['id_produto'] ? 'Editar produto' : 'Novo produto' ?></h2>
        <form method="post" action="produtos.php">
            <?= csrf_campo() ?>
            <input type="hidden" name="acao" value="salvar">
            <input type="hidden" name="id_produto" value="<?= h($produto['id_produto']) ?>">

            <div class="grade">
                <label>SKU *
                    <input type="text" name="sku" maxlength="20" required value="<?= h($produto['sku']) ?>">
                </label>
                <label>Nome *
                    <input type="text" name="nome" maxlength="120" required value="<?= h($produto['nome']) ?>">
                </label>
                <label>Volume (ml) *
                    <input type="number" name="volume_ml" min="1" required value="<?= h($produto['volume_ml']) ?>">
                </label>
                <label>Preço de venda (R$) *
                    <input type="text" name="preco_venda" inputmode="decimal" placeholder="9,50" required value="<?= h($produto['preco_venda']) ?>">
                </label>
                <label>Categoria *
                    <select name="id_categoria" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($categorias as $c): ?>
                            <option value="<?= $c['id_categoria'] ?>" <?= $c['id_categoria'] == $produto['id_categoria'] ? 'selected' : '' ?>>
                                <?= h($c['nome']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Fornecedor *
                    <select name="id_fornecedor" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($fornecedores as $f): ?>
                            <option value="<?= $f['id_fornecedor'] ?>" <?= $f['id_fornecedor'] == $produto['id_fornecedor'] ? 'selected' : '' ?>>
                                <?= h($f['razao_social']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Estoque mínimo (alerta)
                    <input type="number" name="estoque_minimo" min="0" value="<?= h($produto['estoque_minimo']) ?>">
                </label>
            </div>
            <p class="pequeno">O saldo não é digitado aqui: ele só muda por pedido, cancelamento ou entrada de estoque.</p>

            <div class="botoes">
                <button type="submit">Salvar</button>
                <?php if ($produto['id_produto']): ?><a href="produtos.php">Cancelar</a><?php endif; ?>
            </div>
        </form>
    </section>

    <section class="cartao">
        <h2>Produtos</h2>
        <form method="get" class="busca">
            <input type="text" name="busca" placeholder="Buscar por nome ou SKU" value="<?= h($busca) ?>">
            <select name="filtro">
                <option value="ativos"   <?= $filtro === 'ativos' ? 'selected' : '' ?>>Ativos</option>
                <option value="inativos" <?= $filtro === 'inativos' ? 'selected' : '' ?>>Inativos</option>
                <option value="todos"    <?= $filtro === 'todos' ? 'selected' : '' ?>>Todos</option>
            </select>
            <button type="submit">Filtrar</button>
        </form>

        <table>
            <thead>
                <tr><th>SKU</th><th>Produto</th><th>Categoria</th><th>Fornecedor</th><th class="num">Preço</th><th class="num">Saldo</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($produtos as $p): ?>
                <tr class="<?= $p['ativo'] ? '' : 'inativo' ?>">
                    <td><?= h($p['sku']) ?></td>
                    <td><?= h($p['nome']) ?></td>
                    <td><?= h($p['categoria']) ?></td>
                    <td><?= h($p['fornecedor']) ?></td>
                    <td class="num"><?= moeda($p['preco_venda']) ?></td>
                    <td class="num <?= $p['saldo'] < $p['estoque_minimo'] ? 'critico' : '' ?>"><?= (int) $p['saldo'] ?></td>
                    <td class="acoes">
                        <a href="?editar=<?= $p['id_produto'] ?>">Editar</a>
                        <form method="post">
                            <?= csrf_campo() ?>
                            <input type="hidden" name="id_produto" value="<?= $p['id_produto'] ?>">
                            <?php if ($p['ativo']): ?>
                                <button name="acao" value="desativar" class="link"
                                        onclick="return confirm('Desativar este produto?')">Desativar</button>
                            <?php else: ?>
                                <button name="acao" value="reativar" class="link verde">Reativar</button>
                            <?php endif; ?>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$produtos): ?>
                <tr><td colspan="7" class="vazio">Nenhum produto encontrado.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </section>
<?php rodape();
