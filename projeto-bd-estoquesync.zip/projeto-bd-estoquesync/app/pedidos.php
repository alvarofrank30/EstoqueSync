<?php
// Pedidos: listagem com busca e filtro (lê a view vw_pedido_detalhado),
// detalhe dos itens, e mudança de status (entregar / cancelar).
// Cancelar dispara o gatilho de estorno: os itens voltam ao estoque.
require __DIR__ . '/conexao.php';
require __DIR__ . '/layout.php';

$pdo      = conectar();
$mensagem = '';
$erro     = '';

if (isset($_GET['novo'])) {
    $mensagem = 'Pedido confirmado e estoque atualizado.';
}

// ---------- 1. Ações (POST) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $acao     = $_POST['acao'] ?? '';
    $idPedido = (int) ($_POST['id_pedido'] ?? 0);
    try {
        if ($acao === 'cancelar' || $acao === 'entregar') {
            $novoStatus = $acao === 'cancelar' ? 'cancelado' : 'entregue';
            // Só o campo status pode ser alterado (GRANT UPDATE (status) em 06_seguranca.sql)
            transacao($pdo, fn(PDO $pdo) => $pdo->prepare('UPDATE pedido SET status = ? WHERE id_pedido = ?')
                ->execute([$novoStatus, $idPedido]));
            $mensagem = $acao === 'cancelar'
                ? "Pedido #$idPedido cancelado. Os itens voltaram ao estoque."
                : "Pedido #$idPedido marcado como entregue.";
        }
    } catch (PDOException $e) {
        $erro = mensagem_erro($e);
    }
}

// ---------- 2. Detalhe de um pedido (?ver=ID) ----------
$detalhe = null;
$itens   = [];
if (isset($_GET['ver'])) {
    $st = $pdo->prepare('SELECT *, fn_total_pedido(id_pedido) AS total_funcao FROM vw_pedido_detalhado WHERE id_pedido = ?');
    $st->execute([(int) $_GET['ver']]);
    $detalhe = $st->fetch() ?: null;
    if ($detalhe) {
        $st = $pdo->prepare('SELECT pr.sku, pr.nome, i.quantidade, i.preco_unitario,
                                    i.quantidade * i.preco_unitario AS subtotal
                             FROM item_pedido i JOIN produto pr ON pr.id_produto = i.id_produto
                             WHERE i.id_pedido = ? ORDER BY pr.nome');
        $st->execute([$detalhe['id_pedido']]);
        $itens = $st->fetchAll();
    }
}

// ---------- 3. Listagem com busca e filtro ----------
$busca  = trim($_GET['busca'] ?? '');
$filtro = $_GET['filtro'] ?? 'todos';

$sql = 'SELECT id_pedido, data_pedido, status, cliente, vendedor, qtd_itens, total
        FROM vw_pedido_detalhado
        WHERE (cliente ILIKE ? OR vendedor ILIKE ?)';
$params = ["%$busca%", "%$busca%"];
if (in_array($filtro, ['confirmado', 'entregue', 'cancelado'], true)) {
    $sql .= ' AND status = ?';
    $params[] = $filtro;
}
$sql .= ' ORDER BY id_pedido DESC LIMIT 50';

$st = $pdo->prepare($sql);
$st->execute($params);
$pedidos = $st->fetchAll();

cabecalho('Pedidos', 'pedidos');
avisos($mensagem, $erro);
?>
<?php if ($detalhe): ?>
    <section class="cartao">
        <h2>Pedido #<?= (int) $detalhe['id_pedido'] ?> <span class="etq <?= h($detalhe['status']) ?>"><?= h($detalhe['status']) ?></span></h2>
        <p class="pequeno">
            <?= h($detalhe['cliente']) ?> · vendedor <?= h($detalhe['vendedor']) ?> ·
            <?= h(date('d/m/Y H:i', strtotime($detalhe['data_pedido']))) ?>
        </p>
        <table>
            <thead><tr><th>SKU</th><th>Produto</th><th class="num">Qtd</th><th class="num">Preço un.</th><th class="num">Subtotal</th></tr></thead>
            <tbody>
            <?php foreach ($itens as $i): ?>
                <tr>
                    <td><?= h($i['sku']) ?></td><td><?= h($i['nome']) ?></td>
                    <td class="num"><?= (int) $i['quantidade'] ?></td>
                    <td class="num"><?= moeda($i['preco_unitario']) ?></td>
                    <td class="num"><?= moeda($i['subtotal']) ?></td>
                </tr>
            <?php endforeach; ?>
            <tr><td colspan="4" class="num"><strong>Total (fn_total_pedido)</strong></td>
                <td class="num"><strong><?= moeda($detalhe['total_funcao']) ?></strong></td></tr>
            </tbody>
        </table>
        <p><a href="pedidos.php">Fechar detalhe</a></p>
    </section>
<?php endif; ?>

    <section class="cartao">
        <h2>Últimos pedidos</h2>
        <form method="get" class="busca">
            <input type="text" name="busca" placeholder="Buscar por cliente ou vendedor" value="<?= h($busca) ?>">
            <select name="filtro">
                <?php foreach (['todos' => 'Todos', 'confirmado' => 'Confirmados', 'entregue' => 'Entregues', 'cancelado' => 'Cancelados'] as $v => $r): ?>
                    <option value="<?= $v ?>" <?= $filtro === $v ? 'selected' : '' ?>><?= $r ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Filtrar</button>
        </form>

        <table>
            <thead>
                <tr><th>#</th><th>Data</th><th>Cliente</th><th>Vendedor</th><th class="num">Itens</th><th class="num">Total</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($pedidos as $p): ?>
                <tr class="<?= $p['status'] === 'cancelado' ? 'inativo' : '' ?>">
                    <td><a href="?ver=<?= $p['id_pedido'] ?>"><?= (int) $p['id_pedido'] ?></a></td>
                    <td><?= h(date('d/m/Y', strtotime($p['data_pedido']))) ?></td>
                    <td><?= h($p['cliente']) ?></td>
                    <td><?= h($p['vendedor']) ?></td>
                    <td class="num"><?= (int) $p['qtd_itens'] ?></td>
                    <td class="num"><?= moeda($p['total']) ?></td>
                    <td><span class="etq <?= h($p['status']) ?>"><?= h($p['status']) ?></span></td>
                    <td class="acoes">
                        <?php if ($p['status'] === 'confirmado'): ?>
                            <form method="post">
                                <?= csrf_campo() ?>
                                <input type="hidden" name="id_pedido" value="<?= $p['id_pedido'] ?>">
                                <button name="acao" value="entregar" class="link verde">Entregar</button>
                            </form>
                            <form method="post">
                                <?= csrf_campo() ?>
                                <input type="hidden" name="id_pedido" value="<?= $p['id_pedido'] ?>">
                                <button name="acao" value="cancelar" class="link"
                                        onclick="return confirm('Cancelar o pedido e devolver os itens ao estoque?')">Cancelar</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$pedidos): ?>
                <tr><td colspan="8" class="vazio">Nenhum pedido encontrado.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        <p class="pequeno">Mostrando os 50 pedidos mais recentes. Pedido entregue ou cancelado não pode mais ser alterado.</p>
    </section>
<?php rodape();
