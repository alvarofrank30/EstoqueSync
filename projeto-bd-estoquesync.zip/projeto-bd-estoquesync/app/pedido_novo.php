<?php
// Novo pedido: a OPERAÇÃO DE MOVIMENTO do sistema, gravada em várias tabelas
// dentro de UMA transação (BEGIN / COMMIT / ROLLBACK):
//   pedido  +  item_pedido (N linhas)  ->  gatilhos: movimentacao_estoque  ->  estoque.saldo
// Se qualquer item não tiver saldo, o banco levanta o erro EST01 e o ROLLBACK
// desfaz TUDO: não sobra pedido pela metade nem estoque descontado.
require __DIR__ . '/conexao.php';
require __DIR__ . '/layout.php';

const LINHAS = 6;   // quantidade de linhas de item exibidas no formulário

$pdo  = conectar();
$erro = '';

$clientes  = $pdo->query('SELECT id_cliente, nome FROM cliente WHERE ativo ORDER BY nome')->fetchAll();
$vendedores = $pdo->query('SELECT id_vendedor, nome FROM vendedor WHERE ativo ORDER BY nome')->fetchAll();
// fn_saldo_disponivel() é a função do banco que responde "posso vender isto agora?"
$produtos  = $pdo->query('SELECT id_produto, sku, nome, preco_venda, fn_saldo_disponivel(id_produto) AS saldo
                          FROM produto WHERE ativo ORDER BY nome')->fetchAll();

$cliente = (int) ($_POST['id_cliente'] ?? 0);
$vendedor = (int) ($_POST['id_vendedor'] ?? 0);
$observacao = trim($_POST['observacao'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    // Junta as linhas preenchidas (produto + quantidade); linhas em branco são ignoradas
    $itens = [];
    $repetido = false;
    for ($i = 0; $i < LINHAS; $i++) {
        $produto = (int) ($_POST['produto'][$i] ?? 0);
        $qtd     = (int) ($_POST['quantidade'][$i] ?? 0);
        if ($produto === 0 && $qtd === 0) continue;
        if (isset($itens[$produto])) $repetido = true;
        $itens[$produto] = $qtd;
    }

    if (!$cliente || !$vendedor) {
        $erro = 'Escolha o cliente e o vendedor.';
    } elseif (!$itens) {
        $erro = 'Inclua pelo menos um item no pedido.';
    } elseif ($repetido) {
        $erro = 'O mesmo produto aparece em mais de uma linha. Some as quantidades numa linha só.';
    } elseif (in_array(0, array_keys($itens), true) || min($itens) <= 0) {
        $erro = 'Cada linha precisa de um produto e de uma quantidade maior que zero.';
    } else {
        $nomeVendedor = '';
        foreach ($vendedores as $v) if ($v['id_vendedor'] == $vendedor) $nomeVendedor = $v['nome'];

        $pdo->beginTransaction();                                         // BEGIN
        try {
            // quem está operando, para o gatilho de auditoria
            $pdo->prepare("SELECT set_config('app.usuario', ?, true)")->execute([$nomeVendedor]);

            $st = $pdo->prepare('INSERT INTO pedido (id_cliente, id_vendedor, observacao)
                                 VALUES (?, ?, ?) RETURNING id_pedido');
            $st->execute([$cliente, $vendedor, $observacao !== '' ? $observacao : null]);
            $idPedido = (int) $st->fetchColumn();

            $st = $pdo->prepare('INSERT INTO item_pedido (id_pedido, id_produto, quantidade) VALUES (?, ?, ?)');
            foreach ($itens as $idProduto => $qtd) {
                $st->execute([$idPedido, $idProduto, $qtd]);              // gatilhos baixam o estoque
            }

            $pdo->commit();                                               // COMMIT
            header('Location: pedidos.php?ver=' . $idPedido . '&novo=1');  // evita reenvio ao atualizar a página
            exit;
        } catch (PDOException $e) {
            $pdo->rollBack();                                             // ROLLBACK
            $erro = mensagem_erro($e);
            if (str_starts_with((string) $e->getCode(), 'EST')) {
                $erro .= ' O pedido NÃO foi gravado e o estoque não foi alterado.';
            }
        }
    }
}

cabecalho('Novo Pedido', 'novo');
avisos('', $erro);
?>
    <section class="cartao">
        <h2>Lançar pedido</h2>
        <form method="post" action="pedido_novo.php">
            <?= csrf_campo() ?>
            <div class="grade">
                <label>Cliente *
                    <select name="id_cliente" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($clientes as $c): ?>
                            <option value="<?= $c['id_cliente'] ?>" <?= $c['id_cliente'] == $cliente ? 'selected' : '' ?>><?= h($c['nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Vendedor *
                    <select name="id_vendedor" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($vendedores as $v): ?>
                            <option value="<?= $v['id_vendedor'] ?>" <?= $v['id_vendedor'] == $vendedor ? 'selected' : '' ?>><?= h($v['nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </div>
            <label>Observação
                <input type="text" name="observacao" maxlength="200" value="<?= h($observacao) ?>">
            </label>

            <table>
                <thead><tr><th>Produto (saldo atual)</th><th style="width:130px">Quantidade</th></tr></thead>
                <tbody>
                <?php for ($i = 0; $i < LINHAS; $i++): $sel = (int) ($_POST['produto'][$i] ?? 0); ?>
                    <tr>
                        <td>
                            <select name="produto[]" style="margin:0">
                                <option value="0">—</option>
                                <?php foreach ($produtos as $p): ?>
                                    <option value="<?= $p['id_produto'] ?>" <?= $p['id_produto'] == $sel ? 'selected' : '' ?>>
                                        <?= h($p['nome']) ?> · <?= moeda($p['preco_venda']) ?> · saldo <?= (int) $p['saldo'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td><input type="number" name="quantidade[]" min="0" style="margin:0"
                                   value="<?= h($_POST['quantidade'][$i] ?? '') ?>"></td>
                    </tr>
                <?php endfor; ?>
                </tbody>
            </table>
            <p class="pequeno">O preço é o do catálogo no momento da venda. Deixe em branco as linhas que não usar.</p>

            <div class="botoes">
                <button type="submit">Confirmar pedido</button>
            </div>
        </form>
    </section>
<?php rodape();
