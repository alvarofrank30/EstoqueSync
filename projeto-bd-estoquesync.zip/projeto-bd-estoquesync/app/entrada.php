<?php
// Entrada de estoque: registra o recebimento de mercadoria do fornecedor.
// A tela só insere uma linha em movimentacao_estoque (tipo 'entrada');
// quem soma o saldo é o gatilho trg_aplicar_movimentacao. A aplicação não
// tem permissão para alterar estoque.saldo diretamente.
require __DIR__ . '/conexao.php';
require __DIR__ . '/layout.php';

$pdo      = conectar();
$mensagem = '';
$erro     = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $produto    = (int) ($_POST['id_produto'] ?? 0);
    $quantidade = (int) ($_POST['quantidade'] ?? 0);
    $obs        = trim($_POST['observacao'] ?? '') ?: 'Recebimento de fornecedor';

    if (!$produto || $quantidade <= 0) {
        $erro = 'Escolha o produto e informe uma quantidade maior que zero.';
    } else {
        try {
            transacao($pdo, fn(PDO $pdo) => $pdo->prepare(
                "INSERT INTO movimentacao_estoque (tipo, quantidade, observacao, id_produto)
                 VALUES ('entrada', ?, ?, ?)"
            )->execute([$quantidade, $obs, $produto]));
            $mensagem = 'Entrada registrada. O saldo foi atualizado.';
        } catch (PDOException $e) {
            $erro = mensagem_erro($e);
        }
    }
}

$produtos = $pdo->query('SELECT p.id_produto, p.nome, e.saldo, e.estoque_minimo
                         FROM produto p JOIN estoque e ON e.id_produto = p.id_produto
                         WHERE p.ativo ORDER BY p.nome')->fetchAll();

$ultimas = $pdo->query("SELECT m.data_movimento, pr.nome AS produto, m.quantidade, m.observacao
                        FROM movimentacao_estoque m JOIN produto pr ON pr.id_produto = m.id_produto
                        WHERE m.tipo = 'entrada'
                        ORDER BY m.data_movimento DESC, m.id_movimentacao_estoque DESC LIMIT 10")->fetchAll();

cabecalho('Entrada de Estoque', 'entrada');
avisos($mensagem, $erro);
?>
    <section class="cartao">
        <h2>Registrar recebimento</h2>
        <form method="post" action="entrada.php">
            <?= csrf_campo() ?>
            <div class="grade">
                <label>Produto *
                    <select name="id_produto" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($produtos as $p): ?>
                            <option value="<?= $p['id_produto'] ?>" <?= $p['id_produto'] == ($_POST['id_produto'] ?? 0) ? 'selected' : '' ?>>
                                <?= h($p['nome']) ?> · saldo <?= (int) $p['saldo'] ?> (mín. <?= (int) $p['estoque_minimo'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Quantidade recebida *
                    <input type="number" name="quantidade" min="1" required>
                </label>
                <label>Observação
                    <input type="text" name="observacao" maxlength="120" placeholder="Ex.: NF 1234 do fornecedor">
                </label>
            </div>
            <div class="botoes"><button type="submit">Registrar entrada</button></div>
        </form>
    </section>

    <section class="cartao">
        <h2>Últimas entradas</h2>
        <table>
            <thead><tr><th>Data</th><th>Produto</th><th class="num">Qtd</th><th>Observação</th></tr></thead>
            <tbody>
            <?php foreach ($ultimas as $u): ?>
                <tr>
                    <td><?= h(date('d/m/Y H:i', strtotime($u['data_movimento']))) ?></td>
                    <td><?= h($u['produto']) ?></td>
                    <td class="num"><?= (int) $u['quantidade'] ?></td>
                    <td><?= h($u['observacao']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </section>
<?php rodape();
