<?php
// Página inicial: indicadores rápidos e atalhos.
require __DIR__ . '/conexao.php';
require __DIR__ . '/layout.php';

$pdo = conectar();

$ind = $pdo->query("SELECT
        (SELECT COUNT(*) FROM produto WHERE ativo)                     AS produtos,
        (SELECT COUNT(*) FROM cliente WHERE ativo)                     AS clientes,
        (SELECT COUNT(*) FROM pedido  WHERE status = 'confirmado')     AS abertos,
        (SELECT COUNT(*) FROM vw_estoque_critico)                      AS criticos")->fetch();

cabecalho('EstoqueSync', 'inicio');
?>
    <p>Estoque e pedidos no mesmo banco: o pedido só é aceito se houver saldo, e o saldo se atualiza sozinho.</p>

    <div class="indicadores">
        <div class="indicador"><b><?= (int) $ind['produtos'] ?></b><small>produtos ativos</small></div>
        <div class="indicador"><b><?= (int) $ind['clientes'] ?></b><small>clientes ativos</small></div>
        <div class="indicador"><b><?= (int) $ind['abertos'] ?></b><small>pedidos aguardando entrega</small></div>
        <div class="indicador alerta"><b><?= (int) $ind['criticos'] ?></b><small><a href="relatorio.php">produtos abaixo do mínimo</a></small></div>
    </div>

    <section class="cartao">
        <h2>Atalhos</h2>
        <p><a href="pedido_novo.php">Lançar um novo pedido</a> · <a href="entrada.php">Registrar entrada de estoque</a> ·
           <a href="relatorio.php">Ver estoque crítico</a></p>
    </section>
<?php rodape();
