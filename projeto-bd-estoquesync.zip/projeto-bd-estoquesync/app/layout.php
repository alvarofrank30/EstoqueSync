<?php
// Cabeçalho, menu e rodapé compartilhados por todas as telas.

function cabecalho(string $titulo, string $aba = ''): void
{
    $menu = [
        'inicio'       => ['index.php',        'Início'],
        'produtos'     => ['produtos.php',     'Produtos'],
        'clientes'     => ['clientes.php',     'Clientes'],
        'fornecedores' => ['fornecedores.php', 'Fornecedores'],
        'novo'         => ['pedido_novo.php',  'Novo pedido'],
        'pedidos'      => ['pedidos.php',      'Pedidos'],
        'entrada'      => ['entrada.php',      'Entrada de estoque'],
        'relatorio'    => ['relatorio.php',    'Estoque crítico'],
    ];
    ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= h($titulo) ?> · EstoqueSync</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
<header class="topo">
    <div class="topo-in">
        <strong class="marca">EstoqueSync <span>Distribuidora Rio Capim Bebidas</span></strong>
        <nav>
            <?php foreach ($menu as $chave => [$url, $rotulo]): ?>
                <a href="<?= $url ?>" class="<?= $chave === $aba ? 'ativa' : '' ?>"><?= h($rotulo) ?></a>
            <?php endforeach; ?>
        </nav>
    </div>
</header>
<main>
    <h1><?= h($titulo) ?></h1>
<?php
}

function avisos(string $mensagem, string $erro): void
{
    if ($mensagem !== '') echo '<p class="aviso ok">' . h($mensagem) . '</p>';
    if ($erro !== '')     echo '<p class="aviso erro">' . h($erro) . '</p>';
}

function rodape(): void
{
    echo "</main>\n</body>\n</html>\n";
}
