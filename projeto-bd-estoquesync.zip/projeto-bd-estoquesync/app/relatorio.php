<?php
// Relatórios alimentados por VIEWS do banco (nenhum cálculo é feito no PHP):
//   vw_estoque_critico    -> produtos abaixo do mínimo e quanto repor
//   vw_vendas_por_produto -> produtos mais vendidos
require __DIR__ . '/conexao.php';
require __DIR__ . '/layout.php';

$pdo = conectar();

$criticos = $pdo->query('SELECT sku, produto, categoria, fornecedor, saldo, estoque_minimo, qtd_repor
                         FROM vw_estoque_critico ORDER BY qtd_repor DESC, produto')->fetchAll();

$maisVendidos = $pdo->query('SELECT produto, categoria, qtd_pedidos, unidades_vendidas, faturamento
                             FROM vw_vendas_por_produto ORDER BY unidades_vendidas DESC LIMIT 10')->fetchAll();

cabecalho('Estoque Crítico', 'relatorio');
?>
    <section class="cartao">
        <h2>Produtos abaixo do estoque mínimo</h2>
        <p class="pequeno">Fonte: view <code>vw_estoque_critico</code>. Use a tela "Entrada de estoque" quando a mercadoria chegar.</p>
        <table>
            <thead>
                <tr><th>SKU</th><th>Produto</th><th>Categoria</th><th>Fornecedor</th>
                    <th class="num">Saldo</th><th class="num">Mínimo</th><th class="num">Repor</th></tr>
            </thead>
            <tbody>
            <?php foreach ($criticos as $c): ?>
                <tr>
                    <td><?= h($c['sku']) ?></td><td><?= h($c['produto']) ?></td>
                    <td><?= h($c['categoria']) ?></td><td><?= h($c['fornecedor']) ?></td>
                    <td class="num critico"><?= (int) $c['saldo'] ?></td>
                    <td class="num"><?= (int) $c['estoque_minimo'] ?></td>
                    <td class="num"><strong><?= (int) $c['qtd_repor'] ?></strong></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$criticos): ?>
                <tr><td colspan="7" class="vazio">Nenhum produto abaixo do mínimo. 🎉</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </section>

    <section class="cartao">
        <h2>10 produtos mais vendidos</h2>
        <p class="pequeno">Fonte: view <code>vw_vendas_por_produto</code> (pedidos cancelados não contam).</p>
        <table>
            <thead><tr><th>Produto</th><th>Categoria</th><th class="num">Pedidos</th><th class="num">Unidades</th><th class="num">Faturamento</th></tr></thead>
            <tbody>
            <?php foreach ($maisVendidos as $m): ?>
                <tr>
                    <td><?= h($m['produto']) ?></td><td><?= h($m['categoria']) ?></td>
                    <td class="num"><?= (int) $m['qtd_pedidos'] ?></td>
                    <td class="num"><?= (int) $m['unidades_vendidas'] ?></td>
                    <td class="num"><?= moeda($m['faturamento']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </section>
<?php rodape();
