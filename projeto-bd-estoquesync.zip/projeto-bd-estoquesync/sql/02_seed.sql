-- =============================================================
-- 02_seed.sql : povoamento inicial (TODOS os dados são fictícios)
--
-- Volume: 30 produtos, 30 clientes, 12 fornecedores, 6 vendedores,
--         6 categorias e 100 pedidos (tabela de movimento), com seus
--         itens e o livro-razão de estoque (movimentacao_estoque).
--
-- Este script roda ANTES dos gatilhos (04_functions_triggers.sql),
-- então ele mesmo grava as movimentações e calcula o saldo a partir
-- delas. Depois de pronto, vale a regra:
--     saldo = entradas + estornos - saídas
-- (a consulta 11 de 07_consultas.sql confere isso).
--
-- Os valores usam aritmética determinística (sem random()), então o
-- resultado é o mesmo em qualquer máquina.
-- =============================================================

-- ---------- categorias ----------
INSERT INTO categoria (nome) VALUES
    ('Refrigerante'), ('Cerveja'), ('Suco e Néctar'),
    ('Água'), ('Energético'), ('Vinho');

-- ---------- fornecedores (empresas fictícias) ----------
INSERT INTO fornecedor (razao_social, email, telefone, cidade) VALUES
    ('Bebidas Tapajós Ltda',            'contato@bebidastapajos.exemplo.com',  '(91) 90000-0101', 'Belém'),
    ('Cervejaria Rio Capim S.A.',       'vendas@cervejariariocapim.exemplo.com','(91) 90000-0102', 'Paragominas'),
    ('Sucos do Pará Indústria',         'comercial@sucosdopara.exemplo.com',   '(91) 90000-0103', 'Castanhal'),
    ('Águas Cristalinas do Norte',      'pedidos@aguascristalinas.exemplo.com','(91) 90000-0104', 'Ananindeua'),
    ('Refrigerantes Amazônia Ltda',     'contato@refriamazonia.exemplo.com',   '(91) 90000-0105', 'Belém'),
    ('Energéticos Tucumã ME',           'vendas@energeticostucuma.exemplo.com','(91) 90000-0106', 'Marabá'),
    ('Vinhos da Serra Importadora',     'comercial@vinhosdaserra.exemplo.com', '(91) 90000-0107', 'Belém'),
    ('Cia. de Bebidas Marajó',          'contato@bebidasmarajo.exemplo.com',   '(91) 90000-0108', 'Belém'),
    ('Fruta Real Néctares',             'vendas@frutareal.exemplo.com',        '(91) 90000-0109', 'Tomé-Açu'),
    ('Mineral Guamá Ltda',              'pedidos@mineralguama.exemplo.com',    '(91) 90000-0110', 'Capanema'),
    ('Belém Beverages Distribuidora',   'contato@belembeverages.exemplo.com',  NULL,              'Belém'),
    ('Cervejaria Artesanal Cupuaçu',    'vendas@cervejacupuacu.exemplo.com',   '(91) 90000-0112', 'Paragominas');

-- ---------- vendedores (pessoas fictícias) ----------
INSERT INTO vendedor (nome, email, data_admissao) VALUES
    ('Marcos Tavares',   'marcos.tavares@exemplo.com',   '2023-03-10'),
    ('Luciana Prado',    'luciana.prado@exemplo.com',    '2023-08-21'),
    ('Rafael Nogueira',  'rafael.nogueira@exemplo.com',  '2024-01-15'),
    ('Patrícia Moura',   'patricia.moura@exemplo.com',   '2024-06-03'),
    ('Diego Queiroz',    'diego.queiroz@exemplo.com',    '2025-02-17'),
    ('Helena Brandão',   'helena.brandao@exemplo.com',   '2025-09-01');

-- ---------- produtos (30: 6 categorias x 5) ----------
-- ordem das colunas: sku, nome, volume_ml, preco_venda, id_categoria, id_fornecedor
INSERT INTO produto (sku, nome, volume_ml, preco_venda, id_categoria, id_fornecedor) VALUES
    -- 1 Refrigerante
    ('REF-COLA-2L',   'Refrigerante Cola 2 L',            2000,  9.50, 1, 5),
    ('REF-COLA-350',  'Refrigerante Cola Lata 350 ml',     350,  4.20, 1, 5),
    ('REF-GUAR-2L',   'Refrigerante Guaraná 2 L',         2000,  8.90, 1, 1),
    ('REF-GUAR-350',  'Refrigerante Guaraná Lata 350 ml',  350,  3.90, 1, 8),
    ('REF-LARA-2L',   'Refrigerante Laranja 2 L',         2000,  8.50, 1, 8),
    -- 2 Cerveja
    ('CER-PILS-350',  'Cerveja Pilsen Lata 350 ml',        350,  4.50, 2, 2),
    ('CER-PILS-600',  'Cerveja Pilsen Garrafa 600 ml',     600,  8.00, 2, 2),
    ('CER-IPA-355',   'Cerveja IPA Artesanal 355 ml',      355, 12.90, 2, 12),
    ('CER-LAG-330',   'Cerveja Lager Long Neck 330 ml',    330,  6.20, 2, 2),
    ('CER-CUP-500',   'Cerveja de Cupuaçu 500 ml',         500, 15.90, 2, 12),
    -- 3 Suco e Néctar
    ('SUC-ACAI-1L',   'Néctar de Açaí 1 L',               1000, 11.90, 3, 3),
    ('SUC-CAJU-1L',   'Suco de Caju 1 L',                 1000,  9.90, 3, 3),
    ('SUC-UVA-1L',    'Suco de Uva Integral 1 L',         1000, 14.50, 3, 9),
    ('SUC-LARA-1L',   'Suco de Laranja 1 L',              1000, 10.50, 3, 9),
    ('SUC-MARA-1L',   'Néctar de Maracujá 1 L',           1000, 10.90, 3, 9),
    -- 4 Água
    ('AGU-SG-500',    'Água Mineral sem Gás 500 ml',       500,  2.00, 4, 4),
    ('AGU-SG-1500',   'Água Mineral sem Gás 1,5 L',       1500,  3.50, 4, 10),
    ('AGU-CG-500',    'Água Mineral com Gás 500 ml',       500,  2.80, 4, 4),
    ('AGU-GAL-20L',   'Água Mineral Galão 20 L',         20000, 14.00, 4, 10),
    ('AGU-COCO-330',  'Água de Coco 330 ml',               330,  5.50, 4, 3),
    -- 5 Energético
    ('ENE-269',       'Energético Lata 269 ml',            269,  6.90, 5, 6),
    ('ENE-473',       'Energético Lata 473 ml',            473,  9.50, 5, 6),
    ('ENE-ZERO-269',  'Energético Zero Açúcar 269 ml',     269,  7.20, 5, 6),
    ('ENE-GUAR-250',  'Energético de Guaraná 250 ml',      250,  6.50, 5, 1),
    ('ENE-TROP-473',  'Energético Tropical 473 ml',        473,  9.90, 5, 6),
    -- 6 Vinho
    ('VIN-TIN-750',   'Vinho Tinto Seco 750 ml',           750, 39.90, 6, 7),
    ('VIN-BRA-750',   'Vinho Branco Seco 750 ml',          750, 37.90, 6, 7),
    ('VIN-ROS-750',   'Vinho Rosé 750 ml',                 750, 35.90, 6, 7),
    ('VIN-SUA-750',   'Vinho Tinto Suave 750 ml',          750, 29.90, 6, 7),
    ('VIN-ESP-750',   'Espumante Brut 750 ml',             750, 49.90, 6, 11);

-- ---------- clientes (30 estabelecimentos fictícios) ----------
INSERT INTO cliente (nome, email, telefone, cidade) VALUES
    ('Mercadinho Estrela do Norte',   'estrela.norte@exemplo.com',     '(91) 90000-0201', 'Paragominas'),
    ('Bar do Capim',                  'bar.capim@exemplo.com',         '(91) 90000-0202', 'Paragominas'),
    ('Restaurante Sabor da Terra',    'sabor.terra@exemplo.com',       '(91) 90000-0203', 'Paragominas'),
    ('Lanchonete Ponto Certo',        'ponto.certo@exemplo.com',       NULL,              'Paragominas'),
    ('Supermercado Bom Preço Norte',  'bompreco.norte@exemplo.com',    '(91) 90000-0205', 'Paragominas'),
    ('Adega Boa Mesa',                'adega.boamesa@exemplo.com',     '(91) 90000-0206', 'Paragominas'),
    ('Padaria Pão Quente',            'pao.quente@exemplo.com',        '(91) 90000-0207', 'Paragominas'),
    ('Pizzaria Forno Dourado',        'forno.dourado@exemplo.com',     '(91) 90000-0208', 'Paragominas'),
    ('Pousada Rio Verde',             'pousada.rioverde@exemplo.com',  '(91) 90000-0209', 'Paragominas'),
    ('Churrascaria Brasa Viva',       'brasa.viva@exemplo.com',        '(91) 90000-0210', 'Paragominas'),
    ('Mercearia Dois Irmãos',         'dois.irmaos@exemplo.com',       '(91) 90000-0211', 'Ulianópolis'),
    ('Bar e Petiscaria Esquina',      'petiscaria.esquina@exemplo.com','(91) 90000-0212', 'Ulianópolis'),
    ('Sorveteria Gelo Fino',          'gelo.fino@exemplo.com',         '(91) 90000-0213', 'Dom Eliseu'),
    ('Armazém do Zé',                 'armazem.ze@exemplo.com',        '(91) 90000-0214', 'Dom Eliseu'),
    ('Restaurante Panela Cheia',      'panela.cheia@exemplo.com',      NULL,              'Dom Eliseu'),
    ('Mercadão Rondon',               'mercadao.rondon@exemplo.com',   '(91) 90000-0216', 'Rondon do Pará'),
    ('Bar do Porto',                  'bar.porto@exemplo.com',         '(91) 90000-0217', 'Rondon do Pará'),
    ('Lanchonete Sabor Caseiro',      'sabor.caseiro@exemplo.com',     '(91) 90000-0218', 'Goianésia do Pará'),
    ('Mini Mercado Esperança',        'minimercado.esperanca@exemplo.com','(91) 90000-0219','Goianésia do Pará'),
    ('Pousada Beira Rio',             'pousada.beirario@exemplo.com',  '(91) 90000-0220', 'Tomé-Açu'),
    ('Bar Recanto Verde',             'recanto.verde@exemplo.com',     '(91) 90000-0221', 'Tomé-Açu'),
    ('Supermercado Amazônia Center',  'amazonia.center@exemplo.com',   '(91) 90000-0222', 'Mãe do Rio'),
    ('Boteco do Canto',               'boteco.canto@exemplo.com',      '(91) 90000-0223', 'Mãe do Rio'),
    ('Espetinho da Praça',            'espetinho.praca@exemplo.com',   '(91) 90000-0224', 'Paragominas'),
    ('Clube Recreativo Pôr do Sol',   'clube.pordosol@exemplo.com',    '(91) 90000-0225', 'Paragominas'),
    ('Hamburgueria Chapa Quente',     'chapa.quente@exemplo.com',      '(91) 90000-0226', 'Paragominas'),
    ('Quiosque Mirante',              'quiosque.mirante@exemplo.com',  NULL,              'Ipixuna do Pará'),
    ('Empório Sabores do Pará',       'emporio.sabores@exemplo.com',   '(91) 90000-0228', 'Paragominas'),
    ('Cantina do Campus',             'cantina.campus@exemplo.com',    '(91) 90000-0229', 'Paragominas'),
    ('Buffet Festa Boa',              'buffet.festaboa@exemplo.com',   '(91) 90000-0230', 'Paragominas');

-- ---------- estoque: uma linha por produto, saldo calculado no fim ----------
-- id_produto, entrada inicial (há 120 dias), estoque mínimo
CREATE TEMP TABLE tmp_estoque_inicial (id_produto INTEGER, entrada INTEGER, minimo INTEGER);
INSERT INTO tmp_estoque_inicial (id_produto, entrada, minimo)
SELECT id_produto, 150, 40 FROM produto;

-- Produtos de giro alto e pouco estoque inicial: terminam o período abaixo
-- do mínimo e aparecem no relatório de estoque crítico (RN06).
UPDATE tmp_estoque_inicial SET entrada = 100 WHERE id_produto IN (9, 15);
UPDATE tmp_estoque_inicial SET entrada = 90  WHERE id_produto IN (19, 27);
UPDATE tmp_estoque_inicial SET entrada = 80  WHERE id_produto = 21;
UPDATE tmp_estoque_inicial SET entrada = 40  WHERE id_produto = 29;
UPDATE tmp_estoque_inicial SET entrada = 22  WHERE id_produto = 11;  -- quase ruptura: termina com saldo 1

INSERT INTO estoque (id_produto, estoque_minimo)
SELECT id_produto, minimo FROM tmp_estoque_inicial;

-- ---------- pedidos: 100 (tabela de movimento) ----------
-- Pedido n: cliente, vendedor e data distribuídos por aritmética simples.
-- Nascem todos 'confirmado'; o status final é ajustado mais abaixo.
INSERT INTO pedido (data_pedido, id_cliente, id_vendedor, observacao)
SELECT now() - ((101 - n) * interval '1 day') + ((n % 10) * interval '1 hour'),
       ((n * 13) % 29) + 1,      -- clientes 1 a 29 compram; o 30 é recém-cadastrado
       (n % 6) + 1,
       CASE WHEN n % 17 = 0 THEN 'Entrega agendada para a manhã' END
FROM generate_series(1, 100) AS n
ORDER BY n;

-- ---------- itens: 2 a 4 produtos por pedido (preço do catálogo no ato) ----------
INSERT INTO item_pedido (id_pedido, id_produto, quantidade, preco_unitario)
SELECT pe.id_pedido,
       pr.id_produto,
       ((pe.id_pedido * 3 + k * 5) % 12) + 1,
       pr.preco_venda
FROM pedido pe
CROSS JOIN generate_series(0, 3) AS k
JOIN produto pr ON pr.id_produto = ((pe.id_pedido * 7 + k * 11) % 30) + 1
WHERE k <= (pe.id_pedido % 3) + 1;

-- ---------- status final dos pedidos ----------
UPDATE pedido SET status = 'entregue'  WHERE id_pedido <= 90 AND id_pedido % 10 <> 0;
UPDATE pedido SET status = 'cancelado' WHERE id_pedido % 10 = 0;
-- pedidos 91 a 99 continuam 'confirmado' (ainda não entregues)

-- ---------- livro-razão de estoque ----------
-- (a) entrada inicial, há 120 dias
INSERT INTO movimentacao_estoque (tipo, quantidade, data_movimento, observacao, id_produto)
SELECT 'entrada', entrada, now() - interval '120 days', 'Estoque inicial', id_produto
FROM tmp_estoque_inicial;

-- (b) reposição de metade dos produtos, há 60 dias
INSERT INTO movimentacao_estoque (tipo, quantidade, data_movimento, observacao, id_produto)
SELECT 'entrada', 100, now() - interval '60 days', 'Reposição de fornecedor', id_produto
FROM produto WHERE id_produto % 2 = 0;

-- (c) uma saída para cada item vendido
INSERT INTO movimentacao_estoque (tipo, quantidade, data_movimento, observacao, id_produto, id_pedido)
SELECT 'saida', i.quantidade, p.data_pedido, 'Baixa automática pelo pedido', i.id_produto, i.id_pedido
FROM item_pedido i
JOIN pedido p ON p.id_pedido = i.id_pedido;

-- (d) estorno dos itens dos pedidos cancelados
INSERT INTO movimentacao_estoque (tipo, quantidade, data_movimento, observacao, id_produto, id_pedido)
SELECT 'estorno', i.quantidade, p.data_pedido + interval '3 hours', 'Estorno por cancelamento', i.id_produto, i.id_pedido
FROM item_pedido i
JOIN pedido p ON p.id_pedido = i.id_pedido
WHERE p.status = 'cancelado';

-- ---------- saldo = entradas + estornos - saídas ----------
UPDATE estoque e
SET saldo = (SELECT COALESCE(SUM(CASE WHEN m.tipo = 'saida' THEN -m.quantidade ELSE m.quantidade END), 0)
             FROM movimentacao_estoque m
             WHERE m.id_produto = e.id_produto),
    data_atualizacao = now();

DROP TABLE tmp_estoque_inicial;
