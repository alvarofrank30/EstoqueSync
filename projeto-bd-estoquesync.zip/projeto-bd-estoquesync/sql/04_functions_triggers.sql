-- =============================================================
-- 04_functions_triggers.sql : programação dentro do banco
--
-- Funções de consulta (PL/pgSQL):
--   fn_total_pedido, fn_saldo_disponivel
-- Funções de gatilho + gatilhos:
--   auditoria ........ fn_auditar        -> trg_auditar_<tabela>
--   regras de negócio  fn_criar_estoque, fn_preparar_item_pedido,
--                      fn_baixar_estoque, fn_aplicar_movimentacao,
--                      fn_validar_status_pedido, fn_estornar_pedido,
--                      fn_bloquear_alteracao
--
-- Fluxo de uma venda (tudo dentro da transação da aplicação):
--   INSERT item_pedido
--     -> trg_preparar_item_pedido (BEFORE): produto ativo? pedido confirmado? congela o preço
--     -> trg_baixar_estoque (AFTER): grava a 'saida' em movimentacao_estoque
--          -> trg_aplicar_movimentacao (AFTER): desconta o saldo; se não houver
--             saldo, RAISE EXCEPTION 'EST01' e a transação inteira é desfeita
--
-- As funções marcadas SECURITY DEFINER rodam com os privilégios de quem
-- as criou (administrador). É assim que o usuário da aplicação, que NÃO
-- pode alterar estoque.saldo nem escrever em auditoria diretamente,
-- consegue que o gatilho faça isso por ele. Por segurança, essas funções
-- fixam o search_path.
--
-- SQLSTATEs próprios usados nas exceções (a aplicação os reconhece):
--   EST01 estoque insuficiente      EST02 produto desativado
--   EST03 produto inexistente       EST04 pedido não está confirmado
--   EST05 pedido cancelado é final  EST06 pedido entregue não cancela
--   EST07 registro imutável
-- =============================================================

-- -------------------------------------------------------------
-- FUNÇÕES DE CONSULTA
-- -------------------------------------------------------------

-- Total de um pedido = soma de quantidade x preço congelado de cada item.
CREATE OR REPLACE FUNCTION fn_total_pedido(p_id_pedido INTEGER)
RETURNS NUMERIC AS $$
DECLARE
    v_total NUMERIC(12,2);
BEGIN
    SELECT COALESCE(SUM(quantidade * preco_unitario), 0)
      INTO v_total
      FROM item_pedido
     WHERE id_pedido = p_id_pedido;
    RETURN v_total;
END;
$$ LANGUAGE plpgsql STABLE;

-- Saldo atual de um produto. É a pergunta central do sistema:
-- "posso vender isto agora?".
CREATE OR REPLACE FUNCTION fn_saldo_disponivel(p_id_produto INTEGER)
RETURNS INTEGER AS $$
DECLARE
    v_saldo INTEGER;
BEGIN
    SELECT saldo INTO v_saldo FROM estoque WHERE id_produto = p_id_produto;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Produto % não encontrado.', p_id_produto USING ERRCODE = 'EST03';
    END IF;
    RETURN v_saldo;
END;
$$ LANGUAGE plpgsql STABLE;

-- -------------------------------------------------------------
-- GATILHO DE AUDITORIA (exigido pelo roteiro)
-- Registra tabela, operação, quem (usuário do banco e usuário da tela),
-- quando, e os dados antes/depois em JSONB.
-- usuario_app vem de set_config('app.usuario', ...) feito pela aplicação.
-- session_user (e não current_user) porque dentro de SECURITY DEFINER
-- current_user seria o dono da função.
-- -------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_auditar() RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO auditoria (tabela, operacao, usuario_bd, usuario_app, dados_antigos, dados_novos)
    VALUES (TG_TABLE_NAME, TG_OP, session_user,
            NULLIF(current_setting('app.usuario', true), ''),
            CASE WHEN TG_OP <> 'INSERT' THEN to_jsonb(OLD) END,
            CASE WHEN TG_OP <> 'DELETE' THEN to_jsonb(NEW) END);
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp;

CREATE TRIGGER trg_auditar_pedido
    AFTER INSERT OR UPDATE OR DELETE ON pedido
    FOR EACH ROW EXECUTE FUNCTION fn_auditar();
CREATE TRIGGER trg_auditar_produto
    AFTER INSERT OR UPDATE OR DELETE ON produto
    FOR EACH ROW EXECUTE FUNCTION fn_auditar();
CREATE TRIGGER trg_auditar_cliente
    AFTER INSERT OR UPDATE OR DELETE ON cliente
    FOR EACH ROW EXECUTE FUNCTION fn_auditar();
CREATE TRIGGER trg_auditar_fornecedor
    AFTER INSERT OR UPDATE OR DELETE ON fornecedor
    FOR EACH ROW EXECUTE FUNCTION fn_auditar();

-- -------------------------------------------------------------
-- GATILHOS DE REGRA DE NEGÓCIO
-- -------------------------------------------------------------

-- Todo produto novo ganha sua linha de estoque (saldo 0).
CREATE OR REPLACE FUNCTION fn_criar_estoque() RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO estoque (id_produto) VALUES (NEW.id_produto);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp;

CREATE TRIGGER trg_criar_estoque
    AFTER INSERT ON produto
    FOR EACH ROW EXECUTE FUNCTION fn_criar_estoque();

-- Antes de gravar um item: o produto existe e está ativo, o pedido está
-- confirmado e o preço do catálogo é congelado no item.
CREATE OR REPLACE FUNCTION fn_preparar_item_pedido() RETURNS TRIGGER AS $$
DECLARE
    v_preco  NUMERIC(10,2);
    v_ativo  BOOLEAN;
    v_nome   VARCHAR(120);
    v_status VARCHAR(10);
BEGIN
    SELECT preco_venda, ativo, nome INTO v_preco, v_ativo, v_nome
      FROM produto WHERE id_produto = NEW.id_produto;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Produto % não encontrado.', NEW.id_produto USING ERRCODE = 'EST03';
    END IF;
    IF NOT v_ativo THEN
        RAISE EXCEPTION 'O produto "%" está desativado e não pode ser vendido.', v_nome
            USING ERRCODE = 'EST02';
    END IF;

    SELECT status INTO v_status FROM pedido WHERE id_pedido = NEW.id_pedido;
    IF v_status IS DISTINCT FROM 'confirmado' THEN
        RAISE EXCEPTION 'Só é possível lançar itens em pedido confirmado.' USING ERRCODE = 'EST04';
    END IF;

    NEW.preco_unitario := COALESCE(NEW.preco_unitario, v_preco);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_preparar_item_pedido
    BEFORE INSERT ON item_pedido
    FOR EACH ROW EXECUTE FUNCTION fn_preparar_item_pedido();

-- RN02: cada item vendido gera, automaticamente, uma saída no livro-razão.
CREATE OR REPLACE FUNCTION fn_baixar_estoque() RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO movimentacao_estoque
           (tipo, quantidade, data_movimento, observacao, id_produto, id_pedido)
    SELECT 'saida', NEW.quantidade, p.data_pedido, 'Baixa automática pelo pedido',
           NEW.id_produto, NEW.id_pedido
      FROM pedido p
     WHERE p.id_pedido = NEW.id_pedido;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_baixar_estoque
    AFTER INSERT ON item_pedido
    FOR EACH ROW EXECUTE FUNCTION fn_baixar_estoque();

-- RN01 e RN04: aplica a movimentação no saldo. A saída só acontece se
-- houver saldo; o UPDATE condicional é atômico, então duas vendas
-- simultâneas do último item não passam as duas.
CREATE OR REPLACE FUNCTION fn_aplicar_movimentacao() RETURNS TRIGGER AS $$
DECLARE
    v_nome  VARCHAR(120);
    v_saldo INTEGER;
BEGIN
    IF NEW.tipo = 'saida' THEN
        UPDATE estoque
           SET saldo = saldo - NEW.quantidade, data_atualizacao = now()
         WHERE id_produto = NEW.id_produto
           AND saldo >= NEW.quantidade;
        IF NOT FOUND THEN
            SELECT p.nome, e.saldo INTO v_nome, v_saldo
              FROM produto p JOIN estoque e ON e.id_produto = p.id_produto
             WHERE p.id_produto = NEW.id_produto;
            RAISE EXCEPTION 'Estoque insuficiente para "%": disponível %, solicitado %.',
                v_nome, v_saldo, NEW.quantidade USING ERRCODE = 'EST01';
        END IF;
    ELSE  -- entrada ou estorno aumentam o saldo
        UPDATE estoque
           SET saldo = saldo + NEW.quantidade, data_atualizacao = now()
         WHERE id_produto = NEW.id_produto;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp;

CREATE TRIGGER trg_aplicar_movimentacao
    AFTER INSERT ON movimentacao_estoque
    FOR EACH ROW EXECUTE FUNCTION fn_aplicar_movimentacao();

-- Máquina de estados do pedido: confirmado -> entregue ou cancelado.
-- Cancelado é definitivo; entregue não pode ser cancelado.
CREATE OR REPLACE FUNCTION fn_validar_status_pedido() RETURNS TRIGGER AS $$
BEGIN
    IF OLD.status = 'cancelado' THEN
        RAISE EXCEPTION 'Pedido cancelado não pode mais ser alterado.' USING ERRCODE = 'EST05';
    END IF;
    IF OLD.status = 'entregue' AND NEW.status = 'cancelado' THEN
        RAISE EXCEPTION 'Pedido já entregue não pode ser cancelado.' USING ERRCODE = 'EST06';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_validar_status_pedido
    BEFORE UPDATE OF status ON pedido
    FOR EACH ROW EXECUTE FUNCTION fn_validar_status_pedido();

-- RN03: cancelar o pedido devolve os itens ao estoque (estorno).
CREATE OR REPLACE FUNCTION fn_estornar_pedido() RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO movimentacao_estoque
           (tipo, quantidade, observacao, id_produto, id_pedido)
    SELECT 'estorno', quantidade, 'Estorno por cancelamento', id_produto, id_pedido
      FROM item_pedido
     WHERE id_pedido = NEW.id_pedido;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_estornar_pedido
    AFTER UPDATE OF status ON pedido
    FOR EACH ROW WHEN (NEW.status = 'cancelado' AND OLD.status <> 'cancelado')
    EXECUTE FUNCTION fn_estornar_pedido();

-- RN12: itens de pedido e movimentações são imutáveis. Para corrigir uma
-- venda, cancela-se o pedido (que gera o estorno); nunca se edita o passado.
CREATE OR REPLACE FUNCTION fn_bloquear_alteracao() RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'Registros de % não podem ser alterados nem apagados. Cancele o pedido para estornar.',
        TG_TABLE_NAME USING ERRCODE = 'EST07';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_bloquear_item_pedido
    BEFORE UPDATE OR DELETE ON item_pedido
    FOR EACH ROW EXECUTE FUNCTION fn_bloquear_alteracao();
CREATE TRIGGER trg_bloquear_movimentacao_estoque
    BEFORE UPDATE OR DELETE ON movimentacao_estoque
    FOR EACH ROW EXECUTE FUNCTION fn_bloquear_alteracao();
