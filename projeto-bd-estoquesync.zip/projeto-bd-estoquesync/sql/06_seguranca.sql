-- =============================================================
-- 06_seguranca.sql : perfis de acesso (roles), GRANT e REVOKE
--
-- Princípio do menor privilégio: cada sistema recebe só o que precisa.
-- A aplicação NUNCA se conecta como postgres.
--
--  Perfil          Quem usa                      O que pode
--  --------------  ----------------------------  -----------------------------------
--  administrador   DBA da equipe                 tudo nas tabelas (inclusive DELETE)
--  app_sistema     a interface web (PHP)         ler; cadastrar/editar produto,
--                                                cliente e fornecedor; lançar pedido,
--                                                cancelar/entregar, registrar entrada
--  leitura         analistas, relatórios         SELECT em todas as tabelas
--  sistema_vendas  OUTRO sistema (de vendas)     SELECT somente em vw_saldo_produto
--
-- As senhas abaixo são provisórias: troque-as (README, passo 3).
-- =============================================================

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'administrador') THEN
        CREATE ROLE administrador LOGIN PASSWORD 'troque_esta_senha';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_sistema') THEN
        CREATE ROLE app_sistema LOGIN PASSWORD 'troque_esta_senha';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'leitura') THEN
        CREATE ROLE leitura NOLOGIN;           -- perfil "de grupo"
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sistema_vendas') THEN
        CREATE ROLE sistema_vendas LOGIN PASSWORD 'troque_esta_senha';
    END IF;
END $$;

-- Permissão de conexão no banco atual (funciona com qualquer nome de banco)
DO $$
BEGIN
    EXECUTE format('GRANT CONNECT ON DATABASE %I TO administrador, app_sistema, leitura, sistema_vendas',
                   current_database());
END $$;

-- Ninguém herda nada por padrão
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO administrador, app_sistema, leitura, sistema_vendas;

-- ---------- administrador ----------
GRANT ALL PRIVILEGES ON ALL TABLES    IN SCHEMA public TO administrador;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO administrador;

-- ---------- leitura (somente consulta) ----------
GRANT SELECT ON ALL TABLES IN SCHEMA public TO leitura;

-- ---------- app_sistema (a interface) ----------
-- Leitura do que as telas precisam (auditoria fica de fora: a aplicação
-- nem enxerga a trilha de auditoria).
GRANT SELECT ON categoria, fornecedor, produto, estoque, cliente, vendedor,
                pedido, item_pedido, movimentacao_estoque TO app_sistema;
GRANT SELECT ON vw_estoque_critico, vw_pedido_detalhado,
                vw_vendas_por_produto, vw_saldo_produto TO app_sistema;

-- Cadastros completos (incluir e editar). Sem DELETE: exclusão é lógica.
GRANT INSERT, UPDATE ON produto, cliente, fornecedor TO app_sistema;

-- Movimento: lançar pedido e itens; registrar entradas de estoque.
GRANT INSERT ON pedido, item_pedido, movimentacao_estoque TO app_sistema;

-- Só o status do pedido pode mudar (cancelar ou marcar como entregue).
GRANT UPDATE (status) ON pedido TO app_sistema;

-- O saldo NÃO pode ser alterado pela aplicação (só pelos gatilhos);
-- ela pode apenas ajustar o estoque mínimo.
GRANT UPDATE (estoque_minimo) ON estoque TO app_sistema;

-- ---------- sistema_vendas (integração com outros sistemas) ----------
GRANT SELECT ON vw_saldo_produto TO sistema_vendas;

-- Garantia explícita (documenta a intenção; DELETE nunca foi concedido):
REVOKE DELETE ON ALL TABLES IN SCHEMA public FROM app_sistema, leitura, sistema_vendas;
