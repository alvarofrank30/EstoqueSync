-- =============================================================
-- 03_views.sql : visões (consultas prontas e reutilizáveis)
-- As views não dependem de funções, para poderem ser criadas
-- antes do script 04.
-- =============================================================

-- -------------------------------------------------------------
-- vw_estoque_critico : produtos ativos com saldo abaixo do mínimo.
-- Alimenta o RELATÓRIO da interface (relatorio.php). RN06.
-- -------------------------------------------------------------
CREATE OR REPLACE VIEW vw_estoque_critico AS
SELECT p.id_produto,
       p.sku,
       p.nome                         AS produto,
       c.nome                         AS categoria,
       f.razao_social                 AS fornecedor,
       e.saldo,
       e.estoque_minimo,
       e.estoque_minimo - e.saldo     AS qtd_repor
FROM produto p
JOIN estoque    e ON e.id_produto    = p.id_produto
JOIN categoria  c ON c.id_categoria  = p.id_categoria
JOIN fornecedor f ON f.id_fornecedor = p.id_fornecedor
WHERE p.ativo
  AND e.saldo < e.estoque_minimo;

-- -------------------------------------------------------------
-- vw_pedido_detalhado : cada pedido com cliente, vendedor, nº de itens
-- e total. Alimenta a tela de pedidos (pedidos.php).
-- -------------------------------------------------------------
CREATE OR REPLACE VIEW vw_pedido_detalhado AS
SELECT p.id_pedido,
       p.data_pedido,
       p.status,
       c.id_cliente,
       c.nome                                          AS cliente,
       v.nome                                          AS vendedor,
       COUNT(i.id_produto)                             AS qtd_itens,
       COALESCE(SUM(i.quantidade * i.preco_unitario), 0) AS total
FROM pedido p
JOIN cliente  c ON c.id_cliente  = p.id_cliente
JOIN vendedor v ON v.id_vendedor = p.id_vendedor
LEFT JOIN item_pedido i ON i.id_pedido = p.id_pedido
GROUP BY p.id_pedido, p.data_pedido, p.status, c.id_cliente, c.nome, v.nome;

-- -------------------------------------------------------------
-- vw_vendas_por_produto : unidades vendidas e faturamento por produto
-- (pedidos cancelados não contam).
-- -------------------------------------------------------------
CREATE OR REPLACE VIEW vw_vendas_por_produto AS
SELECT pr.id_produto,
       pr.sku,
       pr.nome                              AS produto,
       c.nome                               AS categoria,
       COUNT(DISTINCT pe.id_pedido)         AS qtd_pedidos,
       SUM(i.quantidade)                    AS unidades_vendidas,
       SUM(i.quantidade * i.preco_unitario) AS faturamento
FROM item_pedido i
JOIN pedido    pe ON pe.id_pedido    = i.id_pedido
JOIN produto   pr ON pr.id_produto   = i.id_produto
JOIN categoria c  ON c.id_categoria  = pr.id_categoria
WHERE pe.status <> 'cancelado'
GROUP BY pr.id_produto, pr.sku, pr.nome, c.nome;

-- -------------------------------------------------------------
-- vw_saldo_produto : a "porta de entrada" para OUTROS SISTEMAS
-- (ex.: o sistema de vendas). Mostra só o necessário para saber se
-- o produto está disponível antes de lançar o pedido. O perfil
-- sistema_vendas tem SELECT apenas nesta view (ver 06_seguranca.sql).
-- -------------------------------------------------------------
CREATE OR REPLACE VIEW vw_saldo_produto AS
SELECT p.id_produto,
       p.sku,
       p.nome        AS produto,
       p.preco_venda,
       e.saldo,
       (p.ativo AND e.saldo > 0) AS disponivel
FROM produto p
JOIN estoque e ON e.id_produto = p.id_produto;
