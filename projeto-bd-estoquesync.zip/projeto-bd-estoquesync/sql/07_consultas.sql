-- =============================================================
-- 07_consultas.sql : as 10 perguntas do Termo de Abertura (+1 conferência)
-- Cada consulta responde a uma pergunta real do negócio e é
-- executável sozinha. Recursos de SQL exigidos pelo roteiro:
--   JOIN de 3+ tabelas ...... C1, C3, C8
--   GROUP BY com HAVING ..... C4
--   Subconsulta ............. C6
--   LEFT JOIN ............... C5
--   CTE (WITH) .............. C7
--   Função de janela (extra). C10
-- =============================================================

-- C1. Quais produtos estão abaixo do estoque mínimo e de qual fornecedor repor?
SELECT p.sku, p.nome AS produto, c.nome AS categoria, f.razao_social AS fornecedor,
       e.saldo, e.estoque_minimo, e.estoque_minimo - e.saldo AS qtd_repor
FROM produto p
JOIN estoque    e ON e.id_produto    = p.id_produto
JOIN categoria  c ON c.id_categoria  = p.id_categoria
JOIN fornecedor f ON f.id_fornecedor = p.id_fornecedor
WHERE p.ativo AND e.saldo < e.estoque_minimo
ORDER BY qtd_repor DESC;

-- C2. Quanto a empresa faturou em cada mês (pedidos cancelados não contam)?
SELECT date_trunc('month', pe.data_pedido)::date AS mes,
       COUNT(DISTINCT pe.id_pedido)              AS pedidos,
       SUM(i.quantidade * i.preco_unitario)      AS faturamento
FROM pedido pe
JOIN item_pedido i ON i.id_pedido = pe.id_pedido
WHERE pe.status <> 'cancelado'
GROUP BY date_trunc('month', pe.data_pedido)
ORDER BY mes;

-- C3. Quais são os 10 produtos mais vendidos e quanto cada um gerou?
SELECT pr.sku, pr.nome AS produto, c.nome AS categoria,
       SUM(i.quantidade)                    AS unidades,
       SUM(i.quantidade * i.preco_unitario) AS faturamento
FROM item_pedido i
JOIN pedido    pe ON pe.id_pedido   = i.id_pedido
JOIN produto   pr ON pr.id_produto  = i.id_produto
JOIN categoria c  ON c.id_categoria = pr.id_categoria
WHERE pe.status <> 'cancelado'
GROUP BY pr.sku, pr.nome, c.nome
ORDER BY unidades DESC
LIMIT 10;

-- C4. Quais vendedores fecharam mais de 15 pedidos (excluindo cancelados)?
SELECT v.nome AS vendedor, COUNT(*) AS pedidos
FROM pedido pe
JOIN vendedor v ON v.id_vendedor = pe.id_vendedor
WHERE pe.status <> 'cancelado'
GROUP BY v.nome
HAVING COUNT(*) > 15
ORDER BY pedidos DESC;

-- C5. Quais clientes cadastrados nunca fizeram um pedido?
--     (No seed, o cliente 30 foi cadastrado e ainda não comprou.)
SELECT c.id_cliente, c.nome, c.cidade, c.data_cadastro::date AS cadastro
FROM cliente c
LEFT JOIN pedido pe ON pe.id_cliente = c.id_cliente
WHERE pe.id_pedido IS NULL
ORDER BY c.nome;

-- C6. Quais pedidos têm valor acima da média de todos os pedidos?
SELECT d.id_pedido, d.data_pedido::date AS data, d.cliente, d.status, d.total
FROM vw_pedido_detalhado d
WHERE d.total > (SELECT AVG(total) FROM vw_pedido_detalhado)
ORDER BY d.total DESC
LIMIT 15;

-- C7. Quais clientes gastaram mais do que o gasto médio por cliente?
WITH gasto_cliente AS (
    SELECT pe.id_cliente, SUM(i.quantidade * i.preco_unitario) AS gasto
    FROM pedido pe
    JOIN item_pedido i ON i.id_pedido = pe.id_pedido
    WHERE pe.status <> 'cancelado'
    GROUP BY pe.id_cliente
)
SELECT c.nome AS cliente, c.cidade, g.gasto
FROM gasto_cliente g
JOIN cliente c ON c.id_cliente = g.id_cliente
WHERE g.gasto > (SELECT AVG(gasto) FROM gasto_cliente)
ORDER BY g.gasto DESC;

-- C8. Qual o extrato (kardex) de um produto: entradas, saídas e estornos,
--     com o pedido e o cliente de cada saída? (produto CER-PILS-350)
SELECT m.data_movimento::date AS data, m.tipo, m.quantidade,
       m.id_pedido, cl.nome AS cliente, m.observacao
FROM movimentacao_estoque m
JOIN produto pr        ON pr.id_produto = m.id_produto
LEFT JOIN pedido pe    ON pe.id_pedido  = m.id_pedido
LEFT JOIN cliente cl   ON cl.id_cliente = pe.id_cliente
WHERE pr.sku = 'CER-PILS-350'
ORDER BY m.data_movimento, m.id_movimentacao_estoque
LIMIT 20;

-- C9. Quantos pedidos cada vendedor cancelou e qual o valor devolvido ao estoque?
SELECT v.nome AS vendedor,
       COUNT(*) FILTER (WHERE d.status = 'cancelado')                 AS cancelados,
       COALESCE(SUM(d.total) FILTER (WHERE d.status = 'cancelado'), 0) AS valor_cancelado,
       COUNT(*)                                                       AS total_pedidos
FROM vw_pedido_detalhado d
JOIN pedido pe  ON pe.id_pedido   = d.id_pedido
JOIN vendedor v ON v.id_vendedor  = pe.id_vendedor
GROUP BY v.nome
ORDER BY cancelados DESC, v.nome;

-- C10. Qual o ranking de faturamento dos produtos dentro de cada categoria?
--      (função de janela RANK: conta como ponto extra)
SELECT categoria, produto, faturamento,
       RANK() OVER (PARTITION BY categoria ORDER BY faturamento DESC) AS posicao
FROM vw_vendas_por_produto
ORDER BY categoria, posicao;

-- C11. (Conferência) O saldo de cada produto bate com o livro-razão?
--      Esperado: nenhuma linha. Qualquer linha indica inconsistência.
SELECT e.id_produto, e.saldo AS saldo_tabela,
       COALESCE(SUM(CASE WHEN m.tipo = 'saida' THEN -m.quantidade ELSE m.quantidade END), 0) AS saldo_razao
FROM estoque e
LEFT JOIN movimentacao_estoque m ON m.id_produto = e.id_produto
GROUP BY e.id_produto, e.saldo
HAVING e.saldo <> COALESCE(SUM(CASE WHEN m.tipo = 'saida' THEN -m.quantidade ELSE m.quantidade END), 0);
