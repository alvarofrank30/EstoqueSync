-- =============================================================
-- 05_indices.sql : índices além das chaves (PK e UNIQUE já têm índice)
--
-- O PostgreSQL NÃO cria índice automático para colunas de chave
-- estrangeira. Cada índice abaixo existe por causa de uma consulta real
-- do sistema. Para provar o ganho (item 11 da documentação), rode
-- EXPLAIN ANALYZE da consulta ANTES e DEPOIS do CREATE INDEX.
-- Com poucas linhas o planejador prefere varrer a tabela inteira; para
-- ver o índice ser usado num banco de teste, use SET enable_seqscan = off
-- ou carregue mais dados. Os resultados medidos com 200 mil pedidos
-- estão em docs/explain_analyze.md.
-- =============================================================

-- 1) Quais pedidos contêm um produto / quanto cada produto vendeu.
--    A PK de item_pedido é (id_pedido, id_produto): ajuda a buscar por
--    pedido, mas NÃO por produto.
--    Consulta: vw_vendas_por_produto, consultas 3 e 10 de 07_consultas.sql
--      EXPLAIN ANALYZE SELECT SUM(quantidade) FROM item_pedido WHERE id_produto = 6;
CREATE INDEX idx_item_pedido_id_produto ON item_pedido (id_produto);

-- 2) Pedidos de um período (faturamento mensal, relatório por data).
--      EXPLAIN ANALYZE SELECT * FROM pedido WHERE data_pedido >= now() - interval '30 days';
CREATE INDEX idx_pedido_data_pedido ON pedido (data_pedido);

-- 3) Histórico de pedidos de um cliente (consultas 5 e 7).
--      EXPLAIN ANALYZE SELECT * FROM pedido WHERE id_cliente = 12;
CREATE INDEX idx_pedido_id_cliente ON pedido (id_cliente);

-- 4) Extrato (kardex) de um produto, em ordem cronológica (consulta 8).
--    Índice composto: filtra por produto e já entrega ordenado por data.
--      EXPLAIN ANALYZE SELECT * FROM movimentacao_estoque
--       WHERE id_produto = 6 ORDER BY data_movimento;
CREATE INDEX idx_movimentacao_estoque_id_produto ON movimentacao_estoque (id_produto, data_movimento);

-- Atualiza as estatísticas para o planejador escolher bem os planos.
ANALYZE;
