-- =============================================================
-- 01_ddl.sql : criação das tabelas e restrições
-- Sistema: EstoqueSync (Distribuidora Rio Capim Bebidas, empresa fictícia)
-- Banco  : estoque (PostgreSQL 16+)
--
-- Executar como administrador, num banco vazio:
--   createdb estoque
--   psql -v ON_ERROR_STOP=1 -d estoque -f sql/01_ddl.sql
--
-- Convenção de nomes: tabelas no singular e minúsculas; PK id_<tabela>;
-- FK com o mesmo nome da chave referenciada; restrições nomeadas
-- (pk_, fk_, uq_, ck_). Sem acentos nos identificadores.
-- =============================================================

-- Permite rodar o script de novo (reconstrói tudo). CASCADE remove
-- também views e gatilhos que dependam das tabelas.
DROP TABLE IF EXISTS auditoria, movimentacao_estoque, item_pedido, pedido,
                     estoque, produto, vendedor, cliente, fornecedor, categoria CASCADE;

-- -------------------------------------------------------------
-- 1. categoria : agrupa os produtos (refrigerante, cerveja...)
-- -------------------------------------------------------------
CREATE TABLE categoria (
    id_categoria  INTEGER     GENERATED ALWAYS AS IDENTITY,
    nome          VARCHAR(60) NOT NULL,
    ativo         BOOLEAN     NOT NULL DEFAULT true,
    CONSTRAINT pk_categoria      PRIMARY KEY (id_categoria),
    CONSTRAINT uq_categoria_nome UNIQUE (nome)
);

-- -------------------------------------------------------------
-- 2. fornecedor : quem abastece o estoque
-- -------------------------------------------------------------
CREATE TABLE fornecedor (
    id_fornecedor  INTEGER      GENERATED ALWAYS AS IDENTITY,
    razao_social   VARCHAR(120) NOT NULL,
    email          VARCHAR(150) NOT NULL,
    telefone       VARCHAR(15),
    cidade         VARCHAR(60)  NOT NULL,
    data_cadastro  TIMESTAMP    NOT NULL DEFAULT now(),
    ativo          BOOLEAN      NOT NULL DEFAULT true,  -- exclusão lógica
    CONSTRAINT pk_fornecedor       PRIMARY KEY (id_fornecedor),
    CONSTRAINT uq_fornecedor_email UNIQUE (email),
    CONSTRAINT ck_fornecedor_email CHECK (email LIKE '%_@_%')
);

-- -------------------------------------------------------------
-- 3. produto : catálogo de bebidas
-- -------------------------------------------------------------
CREATE TABLE produto (
    id_produto     INTEGER       GENERATED ALWAYS AS IDENTITY,
    sku            VARCHAR(20)   NOT NULL,              -- código interno do produto
    nome           VARCHAR(120)  NOT NULL,
    volume_ml      INTEGER       NOT NULL,
    preco_venda    NUMERIC(10,2) NOT NULL,              -- dinheiro: NUMERIC, nunca REAL
    data_cadastro  TIMESTAMP     NOT NULL DEFAULT now(),
    ativo          BOOLEAN       NOT NULL DEFAULT true, -- exclusão lógica
    id_categoria   INTEGER       NOT NULL,
    id_fornecedor  INTEGER       NOT NULL,
    CONSTRAINT pk_produto        PRIMARY KEY (id_produto),
    CONSTRAINT uq_produto_sku    UNIQUE (sku),
    CONSTRAINT ck_produto_volume CHECK (volume_ml > 0),
    CONSTRAINT ck_produto_preco  CHECK (preco_venda > 0),
    CONSTRAINT fk_produto_categoria  FOREIGN KEY (id_categoria)
        REFERENCES categoria (id_categoria)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_produto_fornecedor FOREIGN KEY (id_fornecedor)
        REFERENCES fornecedor (id_fornecedor)
        ON DELETE RESTRICT ON UPDATE CASCADE
);

-- -------------------------------------------------------------
-- 4. estoque : saldo atual de cada produto (relação 1:1 com produto)
--    Separado de produto porque tem outro ciclo de vida: o catálogo
--    muda raramente; o saldo muda a cada pedido. O saldo só é
--    alterado por gatilho, a partir de movimentacao_estoque.
-- -------------------------------------------------------------
CREATE TABLE estoque (
    id_produto        INTEGER   NOT NULL,   -- PK e FK ao mesmo tempo (1:1)
    saldo             INTEGER   NOT NULL DEFAULT 0,
    estoque_minimo    INTEGER   NOT NULL DEFAULT 20,
    data_atualizacao  TIMESTAMP NOT NULL DEFAULT now(),
    CONSTRAINT pk_estoque        PRIMARY KEY (id_produto),
    CONSTRAINT ck_estoque_saldo  CHECK (saldo >= 0),   -- RN04: saldo nunca negativo
    CONSTRAINT ck_estoque_minimo CHECK (estoque_minimo >= 0),
    CONSTRAINT fk_estoque_produto FOREIGN KEY (id_produto)
        REFERENCES produto (id_produto)
        ON DELETE CASCADE ON UPDATE CASCADE   -- o saldo não existe sem o produto
);

-- -------------------------------------------------------------
-- 5. cliente : bares, mercados e restaurantes atendidos (dados fictícios)
-- -------------------------------------------------------------
CREATE TABLE cliente (
    id_cliente     INTEGER      GENERATED ALWAYS AS IDENTITY,
    nome           VARCHAR(120) NOT NULL,
    email          VARCHAR(150) NOT NULL,
    telefone       VARCHAR(15),
    cidade         VARCHAR(60)  NOT NULL,
    data_cadastro  TIMESTAMP    NOT NULL DEFAULT now(),
    ativo          BOOLEAN      NOT NULL DEFAULT true,
    CONSTRAINT pk_cliente       PRIMARY KEY (id_cliente),
    CONSTRAINT uq_cliente_email UNIQUE (email),
    CONSTRAINT ck_cliente_email CHECK (email LIKE '%_@_%')
);

-- -------------------------------------------------------------
-- 6. vendedor : quem lança os pedidos
-- -------------------------------------------------------------
CREATE TABLE vendedor (
    id_vendedor    INTEGER      GENERATED ALWAYS AS IDENTITY,
    nome           VARCHAR(120) NOT NULL,
    email          VARCHAR(150) NOT NULL,
    data_admissao  DATE         NOT NULL DEFAULT current_date,
    ativo          BOOLEAN      NOT NULL DEFAULT true,
    CONSTRAINT pk_vendedor       PRIMARY KEY (id_vendedor),
    CONSTRAINT uq_vendedor_email UNIQUE (email),
    CONSTRAINT ck_vendedor_email CHECK (email LIKE '%_@_%')
);

-- -------------------------------------------------------------
-- 7. pedido : MOVIMENTO de venda (cabeçalho)
--    O total não é guardado: é calculado por fn_total_pedido()
--    (guardar o total criaria uma dependência transitiva, 3FN).
-- -------------------------------------------------------------
CREATE TABLE pedido (
    id_pedido    INTEGER      GENERATED ALWAYS AS IDENTITY,
    data_pedido  TIMESTAMP    NOT NULL DEFAULT now(),
    status       VARCHAR(10)  NOT NULL DEFAULT 'confirmado',
    observacao   VARCHAR(200),
    id_cliente   INTEGER      NOT NULL,
    id_vendedor  INTEGER      NOT NULL,
    CONSTRAINT pk_pedido        PRIMARY KEY (id_pedido),
    CONSTRAINT ck_pedido_status CHECK (status IN ('confirmado', 'entregue', 'cancelado')),
    CONSTRAINT fk_pedido_cliente  FOREIGN KEY (id_cliente)
        REFERENCES cliente (id_cliente)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_pedido_vendedor FOREIGN KEY (id_vendedor)
        REFERENCES vendedor (id_vendedor)
        ON DELETE RESTRICT ON UPDATE CASCADE
);

-- -------------------------------------------------------------
-- 8. item_pedido : ASSOCIATIVA N:N entre pedido e produto
--    PK composta: o mesmo produto não se repete no mesmo pedido.
--    preco_unitario guarda o preço NO MOMENTO da venda
--    (desnormalização consciente: o preço do catálogo pode mudar).
-- -------------------------------------------------------------
CREATE TABLE item_pedido (
    id_pedido       INTEGER       NOT NULL,
    id_produto      INTEGER       NOT NULL,
    quantidade      INTEGER       NOT NULL,
    preco_unitario  NUMERIC(10,2) NOT NULL,
    CONSTRAINT pk_item_pedido PRIMARY KEY (id_pedido, id_produto),
    CONSTRAINT ck_item_pedido_quantidade CHECK (quantidade > 0),
    CONSTRAINT ck_item_pedido_preco      CHECK (preco_unitario > 0),
    CONSTRAINT fk_item_pedido_pedido  FOREIGN KEY (id_pedido)
        REFERENCES pedido (id_pedido)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_item_pedido_produto FOREIGN KEY (id_produto)
        REFERENCES produto (id_produto)
        ON DELETE RESTRICT ON UPDATE CASCADE
);

-- -------------------------------------------------------------
-- 9. movimentacao_estoque : MOVIMENTO de estoque (livro-razão)
--    Toda mudança de saldo nasce aqui: entrada (recebimento),
--    saida (venda) ou estorno (cancelamento de pedido).
--    Quantidade é sempre positiva; o sinal vem do tipo.
-- -------------------------------------------------------------
CREATE TABLE movimentacao_estoque (
    id_movimentacao_estoque BIGINT      GENERATED ALWAYS AS IDENTITY,
    tipo            VARCHAR(10)  NOT NULL,
    quantidade      INTEGER      NOT NULL,
    data_movimento  TIMESTAMP    NOT NULL DEFAULT now(),
    observacao      VARCHAR(120),
    id_produto      INTEGER      NOT NULL,
    id_pedido       INTEGER,                -- só existe em saida e estorno
    CONSTRAINT pk_movimentacao_estoque PRIMARY KEY (id_movimentacao_estoque),
    CONSTRAINT ck_movimentacao_estoque_tipo       CHECK (tipo IN ('entrada', 'saida', 'estorno')),
    CONSTRAINT ck_movimentacao_estoque_quantidade CHECK (quantidade > 0),
    -- entrada não tem pedido; saída e estorno sempre têm
    CONSTRAINT ck_movimentacao_estoque_pedido CHECK (
        (tipo = 'entrada' AND id_pedido IS NULL)
        OR (tipo IN ('saida', 'estorno') AND id_pedido IS NOT NULL)),
    CONSTRAINT fk_movimentacao_estoque_produto FOREIGN KEY (id_produto)
        REFERENCES produto (id_produto)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_movimentacao_estoque_pedido FOREIGN KEY (id_pedido)
        REFERENCES pedido (id_pedido)
        ON DELETE RESTRICT ON UPDATE CASCADE
);

-- -------------------------------------------------------------
-- 10. auditoria : quem alterou o quê e quando (alimentada por gatilho)
--     Estrutura do exemplo do professor + usuario_app, porque a
--     aplicação sempre conecta como app_sistema e o usuario_bd,
--     sozinho, não diria quem operou a tela.
-- -------------------------------------------------------------
CREATE TABLE auditoria (
    id_auditoria  BIGINT       GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tabela        VARCHAR(60)  NOT NULL,
    operacao      VARCHAR(10)  NOT NULL,
    usuario_bd    VARCHAR(60)  NOT NULL DEFAULT current_user,
    usuario_app   VARCHAR(60),
    momento       TIMESTAMP    NOT NULL DEFAULT now(),
    dados_antigos JSONB,
    dados_novos   JSONB
);
